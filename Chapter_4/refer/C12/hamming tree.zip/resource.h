//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by BP.rc
//
#define IDC_MYICON                      2
#define IDD_BP_DIALOG                   102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_BP                          107
#define IDI_SMALL                       108
#define IDC_BP                          109
#define IDR_MAINFRAME                   128
#define IDD_EMAX                        129
#define IDD_LC                          130
#define IDD_CYCLES                      132
#define IDC_Emax                        1000
#define IDC_LC                          1001
#define IDC_CYCLES                      1002
#define IDM_OPEN                        32771
#define IDM_EMAX                        32772
#define IDM_LC                          32773
#define IDM_STEP                        32774
#define IDM_CYCLES                      32775
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
