#include "stdafx.h"
#include "resource.h"
#include "BP.h"

#define MAX_LOADSTRING 100

/* Global Variables */
HINSTANCE hInst;								// current instance
TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
TCHAR szWindowClass[MAX_LOADSTRING];			// The title bar text
HWND hWindow;

/* Foward declarations of functions included in this code module */
ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);
void                ReadNetFile(TCHAR szFileName[]);
void                InitWeight();
double              unipolar(double net);
char                unipolarD(double net);
LRESULT CALLBACK    CYCLES(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK    EMAX(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK    LC(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
void                Training(int iteration);
void                DrawTree(HDC hdcMain);
void                ShowInfo(HDC hdc);
void                Encoding1();
void                Encoding2();
void                DrawCircle(HDC hdc, int x, int y, int r);
void                Check();

/* Windows Main funtion */
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
 MSG msg;
 HACCEL hAccelTable;

 /* Initialize global strings */
 LoadString(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
 LoadString(hInstance, IDC_BP, szWindowClass, MAX_LOADSTRING);
 MyRegisterClass(hInstance);

 if (!InitInstance (hInstance, nCmdShow)) 
	return FALSE;

 hAccelTable = LoadAccelerators(hInstance, (LPCTSTR)IDC_BP);

 while(GetMessage(&msg, NULL, 0, 0)) 
	{
     if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg)) 
		{
         TranslateMessage(&msg);
		 DispatchMessage(&msg);
		}
	}
 return msg.wParam;
}

/* Register Windows Class */
ATOM MyRegisterClass(HINSTANCE hInstance)
{
 WNDCLASSEX wcex;

 wcex.cbSize        = sizeof(WNDCLASSEX); 
 wcex.style			= CS_HREDRAW | CS_VREDRAW;
 wcex.lpfnWndProc	= (WNDPROC)WndProc;
 wcex.cbClsExtra	= 0;
 wcex.cbWndExtra	= 0;
 wcex.hInstance		= hInstance;
 wcex.hIcon			= LoadIcon(hInstance, (LPCTSTR)IDI_BP);
 wcex.hCursor		= LoadCursor(NULL, IDC_ARROW);
 wcex.hbrBackground	= (HBRUSH)GetStockObject(WHITE_BRUSH);
 wcex.lpszMenuName	= (LPCSTR)IDC_BP;
 wcex.lpszClassName	= szWindowClass;
 wcex.hIconSm		= LoadIcon(wcex.hInstance, (LPCTSTR)IDI_SMALL);

 return RegisterClassEx(&wcex);
}

/* Create Window */
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
 hInst = hInstance; // Store instance handle in our global variable

 hWindow = CreateWindow(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW,
                     CW_USEDEFAULT, 0, CW_USEDEFAULT, 0, NULL, NULL, hInstance, NULL);
 if (!hWindow)
    return FALSE;
 ShowWindow(hWindow, SW_MAXIMIZE);
 UpdateWindow(hWindow);

 return TRUE;
}

/* Windows Procedure */
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
 int wmId, wmEvent;
 PAINTSTRUCT ps;
 HDC hdc;
 TCHAR szHello[MAX_LOADSTRING];
 LoadString(hInst, IDS_HELLO, szHello, MAX_LOADSTRING);
 static OPENFILENAME ofn;
 static TCHAR szFileName[MAX_PATH];
 static TCHAR szFilter[] = TEXT("Net Files (*.net)\0*.net\0")TEXT("All Files (*.*)\0*.*\0\0");
 static HDC		hdcMain;
 static HBITMAP	hBmpMain;

 switch (message) 
	{
     case WM_CREATE:
          // init ofn structure
          ofn.lStructSize       = sizeof (OPENFILENAME);
          ofn.hwndOwner         = hWnd;
          ofn.hInstance         = NULL;
          ofn.lpstrFilter       = szFilter;
          ofn.lpstrCustomFilter = NULL;
          ofn.nMaxCustFilter    = 0;
          ofn.nFilterIndex      = 0;
          ofn.lpstrFile         = szFileName;
          ofn.nMaxFile          = MAX_PATH;
          ofn.lpstrFileTitle    = NULL;
          ofn.nMaxFileTitle     = 0;
          ofn.lpstrInitialDir   = NULL;
          ofn.lpstrTitle        = NULL;
          ofn.Flags             = 0;
          ofn.nFileOffset       = 0;
          ofn.nFileExtension    = 0;
          ofn.lpstrDefExt       = TEXT("net");
          ofn.lCustData         = 0;
          ofn.lpfnHook          = NULL;
          ofn.lpTemplateName    = NULL;
          // �� compatible dc for double buffer
          hdc = GetDC(hWnd);
          hdcMain = CreateCompatibleDC(hdc);
          hBmpMain = CreateCompatibleBitmap(hdc, 1024 , 768);
          SelectObject(hdcMain, hBmpMain);
          ReleaseDC(hWnd, hdc);
          SelectObject(hdcMain, GetStockObject(BLACK_PEN));
          // hdcMain �M���զ�
          RECT rect;
          rect.left = 0;
          rect.right = 1024;
          rect.top = 0;
          rect.bottom = 768;
          FillRect(hdcMain, &rect,(HBRUSH) GetStockObject(WHITE_BRUSH));
          break;
     case WM_KEYDOWN:
          switch( wParam )
             {
              case VK_SPACE:
                   Training(1);
                   DrawTree(hdcMain);
                   InvalidateRect(hWnd, NULL, true);
                   break;
             }
          break;
     case WM_COMMAND:
	      wmId    = LOWORD(wParam); 
		  wmEvent = HIWORD(wParam); 
		  // Parse the menu selections:
		  switch (wmId)
		     {
              case IDM_OPEN:
                   if (!GetOpenFileName(&ofn)) break;
                   ReadNetFile(szFileName);
                   InitWeight();
				   break;
			  case IDM_STEP:
                   Training(1);
                   DrawTree(hdcMain);
                   InvalidateRect(hWnd, NULL, true);
				   break;
              case IDM_CYCLES:
                   DialogBox(hInst, (LPCTSTR)IDD_CYCLES, hWnd, (DLGPROC)CYCLES);
                   Training(iteration);
                   DrawTree(hdcMain);
                   InvalidateRect(hWnd, NULL, true);
                   break;
              case IDM_EMAX:
                   DialogBox(hInst, (LPCTSTR)IDD_EMAX, hWnd, (DLGPROC)EMAX);
                   InvalidateRect(hWnd, NULL, true);
				   break;
              case IDM_LC:
                   DialogBox(hInst, (LPCTSTR)IDD_LC, hWnd, (DLGPROC)LC);
                   InvalidateRect(hWnd, NULL, true);
				   break;
              case IDM_ABOUT:
				   DialogBox(hInst, (LPCTSTR)IDD_ABOUTBOX, hWnd, (DLGPROC)About);
				   break;
			  case IDM_EXIT:
				   DestroyWindow(hWnd);
				   break;
			  default:
				   return DefWindowProc(hWnd, message, wParam, lParam);
			 }
		  break;
	 case WM_PAINT:
	      hdc = BeginPaint(hWnd, &ps);
          ShowInfo(hdcMain);

		  BitBlt(hdc, 0, 0, 1024, 768, hdcMain, 0, 0, SRCCOPY);
          EndPaint(hWnd, &ps);
		  break;
     case WM_DESTROY:
	      DeleteDC(hdcMain);
	      PostQuitMessage(0);
		  break;
     default:
	      return DefWindowProc(hWnd, message, wParam, lParam);
    }
 return 0;
}

/* Message handler for about box */
LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
 switch (message)
	{
     case WM_INITDIALOG:
	      return TRUE;
	 case WM_COMMAND:
		  if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
		     {
			  EndDialog(hDlg, LOWORD(wParam));
			  return TRUE;
			 }
		  break;
	}
 return FALSE;
}

/* Read the training data */
void ReadNetFile(TCHAR szFileName[])
{
 fstream fNet;
 Pattern z;
 Desire d;
 TCHAR tmp[100];
 int dummy;
 fNet.open(szFileName, ios::in);
 if (!fNet) return;
 TP.Z.clear();
 TP.D.clear();
 Complete = false;

 do { fNet >> tmp[0]; } while(tmp[0] != '#');   // # ���e��������
 
 fNet >> tmp;
 if ( stricmp(tmp, "Ninputs") )
    { MessageBox(hWindow, "File format error", "File format error", 0); return; }
 fNet >> dummy;  // input dimension�A�v�w���� 9
 
 fNet >> tmp;
 if ( stricmp(tmp, "Noutputs") )
    { MessageBox(hWindow, "File format error", "File format error", 0); return; }
 fNet >> dummy; // output dimension�A�v�w���� 1
 
 fNet >> tmp;
 if ( stricmp(tmp, "HiddenPool") )
    { MessageBox(hWindow, "File format error", "File format error", 0); return; }
 fNet >> dummy; // Hidden dimension�A�v�w���� 10
 
 fNet >> tmp;
 if ( stricmp(tmp, "NTrainingPatterns") )
    { MessageBox(hWindow, "File format error", "File format error", 0); return; }
 fNet >> dummy; // �ƥؤ����n

 do{
    // input pattern
    for(int i=0; i<I-1; i++)
       fNet >> z.z[i];
    z.z[I-1] = -1;    // augmented input vectors
    TP.Z.push_back(z);
    for(int k=0; k<K; k++)
       fNet >> d.d[k];
    TP.D.push_back(d);
   }
 while(!(fNet.eof()));
 fNet.close();
}

/* Initialize weight matrix with small random number */
void InitWeight()
{
 int i, j, k;
 srand( (unsigned)time(NULL) );
 for(k=0; k<K; k++)
    for(j=0; j<J; j++)
       W[k][j] = double(rand())/RAND_MAX;
 for(j=0; j<J; j++)
    for(i=0; i<I; i++)
       V[j][i] = double(rand())/RAND_MAX;
 Cycle = 0;
}

/* unipolar continuous activation function */
double unipolar(double net)
{
 double tmp = exp(-lamda*net);
 return 1/(1+tmp);
}

/* unipolar discrete activation function */
char unipolarD(double net)
{
 return (net>0) ? '1' : '0';
}

/* ��J iteration */
LRESULT CALLBACK CYCLES(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
 TCHAR buf[30];
 int tmp;
 switch (message)
    {case WM_COMMAND:
          switch (LOWORD (wParam))
             {case IDOK:
                   if ( GetDlgItemText(hDlg, IDC_CYCLES, buf, 29) == 0 )
                      {MessageBox(hDlg, "Emax error!", "Emax error!", MB_ICONERROR);
                       return TRUE;
                      }
                   tmp = atoi(buf);
                   if (tmp > 0)
                      iteration = tmp;
                   EndDialog (hDlg, 1);
                   return TRUE;
              case IDCANCEL:
                   iteration = 0;
                   EndDialog (hDlg, 2);
                   return TRUE;
             }
          break ;
    }
 return FALSE ;
}

/* ��J Emax */
LRESULT CALLBACK EMAX(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
 TCHAR buf[30];
 double tmp;
 switch (message)
    {case WM_COMMAND:
          switch (LOWORD (wParam))
             {case IDOK:
                   if ( GetDlgItemText(hDlg, IDC_Emax, buf, 29) == 0 )
                      {MessageBox(hDlg, "Emax error!", "Emax error!", MB_ICONERROR);
                       return TRUE;
                      }
                   tmp = atof(buf);
                   if ( tmp < Emax ) Complete = false;
                   Emax = tmp;
                   EndDialog (hDlg, 1);
                   return TRUE;
              case IDCANCEL:
                   EndDialog (hDlg, 2);
                   return TRUE;
             }
          break ;
    }
 return FALSE ;
}

/* ��J learning constant lc */
LRESULT CALLBACK LC(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
 TCHAR buf[30];
 switch (message)
    {case WM_COMMAND:
          switch (LOWORD (wParam))
             {case IDOK:
                   if ( GetDlgItemText(hDlg, IDC_LC, buf, 29) == 0 )
                      {MessageBox(hDlg, "�b error!", "�b error!", MB_ICONERROR);
                       return TRUE;
                      }
                   lc = atof(buf);
                   EndDialog (hDlg, 1);
                   return TRUE;
              case IDCANCEL:
                   EndDialog (hDlg, 2);
                   return TRUE;
             }
          break ;
    }
 return FALSE ;
}

/* Training cycle */
void Training(int iteration)
{
 if (Complete) return;
 std::vector<Pattern>::const_iterator ci;
 if(!(ci=TP.Z.begin())) return;
 int size = TP.Z.size();
 int p, i, j, k;
 for(int c=0; c<iteration; c++, Cycle++)    // repeat <iteration> cycles
    {E=0;
     for(p=0; p<size; p++)  // for all training data
        {//compute y
         for(j=0; j<J-1; j++)
            {double sum = 0;
             for(i=0; i<I; i++)
                sum += V[j][i] * TP.Z[p].z[i];
             y[j] = unipolar(sum);
            }
         y[J-1] = -1;
         for(k=0; k<K; k++)
            {double sum = 0;
             for(j=0; j<J; j++)
                sum += W[k][j] * y[j];
             o[k] = unipolar(sum);
            }
         // compute error
         for(k=0; k<K; k++)
            {double d_o = TP.D[p].d[k]-o[k];
             E += 0.5 * d_o * d_o;
            }
         // compute error signal vectors
         double DeltaO[K], DeltaY[J];
         for(k=0; k<K; k++)
            DeltaO[k] = (TP.D[p].d[k] - o[k]) * (1 - o[k]) * o[k];
         for(j=0; j<J; j++)
            {double sum = 0;
             for(k=0; k<K; k++)
                sum += DeltaO[k] * W[k][j];
             DeltaY[j] = y[j] * (1 - y[j]) * sum;
            }
         //adjust W
         for(j=0; j<J; j++)
            for(k=0; k<K; k++)
               W[k][j] += lc * DeltaO[k] * y[j];
         //adjust V
         for(i=0; i<I; i++)
            for(j=0; j<J; j++)
               V[j][i] += lc * DeltaY[j] * TP.Z[p].z[i];
        }//cycles
     Complete = (E<Emax) ? true : false;
     if ( Complete ) break;
    }
}

/* Print E and �b on hdc*/
void ShowInfo(HDC hdc)
{
 TCHAR str[80], buf[40];
 // �M�� hdc
 RECT rect;
 rect.left = 0;
 rect.right = 200;
 rect.top = 0;
 rect.bottom = 100;
 FillRect(hdc, &rect,(HBRUSH) GetStockObject(WHITE_BRUSH));

 strcpy(str, "current Emax = ");
 _gcvt(Emax, 10, buf);
 strcat(str, buf);
 TextOut(hdc, 10, 2, str, strlen(str));
 
 strcpy(str, "current �b = ");
 _gcvt(lc, 10, buf);
 strcat(str, buf);
 TextOut(hdc, 10, 22, str, strlen(str));
 
 std::vector<Pattern>::const_iterator ci;
 if(!(ci=TP.Z.begin())) return;
 strcpy(str, "current E = ");
 _gcvt(E, 10, buf);
 strcat(str, buf);
 TextOut(hdc, 10, 42, str, strlen(str));

 strcpy(str, "Cycles : ");
 itoa(Cycle, buf, 10);
 strcat(str, buf);
 TextOut(hdc, 10, 62, str, strlen(str));

 if (!Complete) return;
 strcpy(str, "Training has completed");
 TextOut(hdc, 10, 82, str, strlen(str));
}

/* Draw the Hamming Tree on hdc */
void DrawTree(HDC hdc)
{
 std::vector<Pattern>::const_iterator ci;
 if(!(ci=TP.Z.begin())) return;
 // �M�� hdc
 RECT rect;
 rect.left = 0;
 rect.right = 1024;
 rect.top = 0;
 rect.bottom = 768;
 FillRect(hdc, &rect,(HBRUSH) GetStockObject(WHITE_BRUSH));
 // Compute encodings
 Encoding1();
 Encoding2();
 Check();
 // Draw Hamming Tree
 // Draw root
 DrawCircle(hdc, 500, 20, 10);
 // Draw Tree
 int n = OutputCode.size();
 int section = 1000/n;
 for(int x=section/2, idx=0; x<1000 && idx<n; x+=section, idx++)
    {//Draw TreeNode2
     DrawCircle(hdc, x, 100, 10);
     HPEN hp;
     if (OutputCode[idx].mix)   //�e��u
        hp = (HPEN) SelectObject(hdc, CreatePen(PS_DOT, 1, RGB(0, 0, 0)));
     else   //�e��u
        hp = (HPEN) SelectObject(hdc, GetStockObject(BLACK_PEN));
     MoveToEx(hdc, x, 100, NULL);
     LineTo(hdc, 500, 20);
     SelectObject(hdc, hp);
     TextOut(hdc, (x+500)/2, (100+20)/2, OutputCode[idx].code, K);
     //Draw TreeNode1 belonging to this TreeNode2
     int n2 = OutputCode[idx].index.size();
     int section2 = section/n2;
     for(int x2=x-section/2+section2/2, idx2=0; x2<x+section/2 && idx2<n2; x2+= section2, idx2++)
        {
         DrawCircle(hdc, x2, 250, 10);   // TreeNode1
         HPEN hp;
         if (HiddenCode[OutputCode[idx].index[idx2]].mix)   //�e��u
            hp = (HPEN) SelectObject(hdc, CreatePen(PS_DOT, 1, RGB(0, 0, 0)));
         else   //�e��u
            hp = (HPEN) SelectObject(hdc, GetStockObject(BLACK_PEN));
         MoveToEx(hdc, x2, 250, NULL);
         LineTo(hdc, x, 100);
         SelectObject(hdc, hp);
         int yy, xx;
         switch(idx2%3)
            {case 0:xx = x2 * 0.7 + x * 0.3 - section2; //�H�K�աA�i�H�ݴN�n :p
                    yy = 250-70;
                    break;
             case 1:xx = x2 * 0.8 + x * 0.2 - section2;
                    yy = 250-50;
                    break;
             case 2:xx = x2 * 0.9 + x * 0.1 - section2;
                    yy = 250-30;
                    break;
            }
         TextOut(hdc, xx, yy, HiddenCode[OutputCode[idx].index[idx2]].code, J-1);
         //�C�X�ݩ�o�� TreeNode1 �� Training pair
         int nPair = HiddenCode[OutputCode[idx].index[idx2]].index.size();
         for(int idx3=0, y3=260; idx3<nPair && y3<740; idx3++, y3+=15)
            {
             char tmp[10];
             int index = HiddenCode[OutputCode[idx].index[idx2]].index[idx3];
             itoa(index, tmp, 10);
             strcat(tmp, ((TP.D[index].d[0] == 0) ? "o" : "x"));
             TextOut(hdc, x2-section2/2, y3, tmp, strlen(tmp));
            }
        }
    }
}

/* �H (x, y) ����ߡA r���b�|�e�@�ӹ�߶� */
void DrawCircle(HDC hdc, int x, int y, int r)
{
 HBRUSH hb = (HBRUSH)SelectObject(hdc, GetStockObject(BLACK_BRUSH));
 Ellipse(hdc, x-r, y-r, x+r, y+r);
 SelectObject(hdc, hb);
}

/* Compute the encoding of training data for hidden layer neurons */
void Encoding1()
{
 int size = TP.Z.size();
 char encoding[J];
 int p, i, j;
 HiddenCode.clear();
 for(p=0; p<size; p++)  // for all training data
    {for(j=0; j<J-1; j++)
        {double sum = 0;
         for(i=0; i<I; i++)
            sum += V[j][i] * TP.Z[p].z[i];
         encoding[j] = unipolarD(sum);
        }
     encoding[J-1] = '\0';
     // search HiddenCode for this encoding
     int size1 = HiddenCode.size();
     for(int ii=0; ii<size1; ii++)
        {if ( strcmp(HiddenCode[ii].code, encoding) == 0 )
            break;
        }
     if (ii<size1)  // found
        {
         HiddenCode[ii].index.push_back(p);
        }
     else   // non-exist encoding => create a new TreeNode1 for this encoding
        {TreeNode1 n1;
         n1.index.push_back(p);  
         strcpy(n1.code, encoding);
         HiddenCode.push_back(n1);
        }
    }
}

/* Compute the encoding for output layer neuron */
void Encoding2()
{
 int size = HiddenCode.size();
 char encoding[K+1];
 int p, j, k;
 OutputCode.clear();
 for(p=0; p<size; p++)  //for all possible hidden encoding
    {for(k=0; k<K; k++)
        {double sum = 0;
         for(j=0; j<J-1; j++)
            sum += W[k][j] * ((HiddenCode[p].code[j] == '1') ? 1 : 0);
         encoding[k] = unipolarD(sum);
        }
     encoding[K] = '\0';
     // search OutputCode for this encoding
     int size2 = OutputCode.size();
     for(int ii=0; ii<size2; ii++)
        {if ( strcmp(OutputCode[ii].code, encoding) == 0 )
           break;
        }
     if (ii<size2)  //found
        OutputCode[ii].index.push_back(p);
     else   // non-exist encoding => create a new TreeNode2 for this encoding
        {TreeNode2 n2;
         n2.index.push_back(p);
         strcpy(n2.code, encoding);
         OutputCode.push_back(n2);
        }
    }
}

/* �ˬd�U�� TreeNode �ҥ]�t�� data ���O�_���������\ 
   ���\ => mix = false                              */
void Check()
{
 int size = HiddenCode.size();
 int i, j;
 for(i=0; i<size; i++)  //for every TreeNode1
    {
     int n = HiddenCode[i].index.size();
     bool zero = false, one = false;
     for(j=0; j<n; j++) //for every training data belonging to this TreeNode1
        {
         if ( TP.D[HiddenCode[i].index[j]].d[0] == 0.0 ) zero = true;
         if ( TP.D[HiddenCode[i].index[j]].d[0] == 1.0 ) one = true;
        }
     if ( zero && one )
        HiddenCode[i].mix = true;
     else
        HiddenCode[i].mix = false;
    }
 size = OutputCode.size();
 for(i=0; i<size; i++)  //for every TreeNode2
    {int n = OutputCode[i].index.size();
     OutputCode[i].mix = false;
     for(j=0; j<n; j++) //for every TreeNode1 belonging to this TreeNode2
        if (HiddenCode[OutputCode[i].index[j]].mix)
           {OutputCode[i].mix = true;
            break;
           }
    }
}

