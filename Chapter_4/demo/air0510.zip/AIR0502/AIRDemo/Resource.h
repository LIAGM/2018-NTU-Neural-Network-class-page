//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AIRDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_AIRDEMTYPE                  129
#define ID_TRAINING_PROCESS             32771
#define ID_TRAINING_TREE                32772
#define ID_ADD_NEURON                   32773
#define ID_TRAIN                        32774
#define ID_STOP                         32775
#define ID_STEP_TRAINING                32776
#define ID_MANUAL_AIR                   32777
#define ID_AIR_ADD                      32777
#define ID_AUTO_AIR                     32778
#define ID_RANDOM_ADD                   32778
#define ID_WEIGHT_MASK                  32779
#define ID_DISPLAY_UPPER_LAYER          32782
#define ID_DISPLAY_LOWER_LAYER          32784
#define ID_REDISTRIBUTE_WEIGHT          32786
#define ID_CHANGE_X_AXIS                32787
#define ID_CHANGE_Y_AXIS                32788

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
