// AIRDemoDoc.h : interface of the CAIRDemoDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_AIRDEMODOC_H__7E3E70F6_8F83_45DB_9D2D_EF0F7654F8F0__INCLUDED_)
#define AFX_AIRDEMODOC_H__7E3E70F6_8F83_45DB_9D2D_EF0F7654F8F0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../BPSystem/AIR_BP.h"

class CAIRDemoDoc : public CDocument
{
protected: // create from serialization only
	CAIRDemoDoc();
	DECLARE_DYNCREATE(CAIRDemoDoc)

// Attributes
public:
//	SuperviseSystem * bp ;
	AIR_BP * bp ;
	double E ;		// current Error

	/////////////////////////////////////////////////////////////////////////////////////
	// Display Mode Info
	/////////////////////////////////////////////////////////////////////////////////////
	BPRect DataBound ;

	// Flag
	enum DisplayMode { Process, Tree }  display_mode ;
	BOOL m_UI_training ;

	// Event for train/stop
	CEvent m_Stop_Event ;


	// which two neurons of which layer
	int CurInputLayer ;
	int CurConflictLayer ;
	int CurXAxis ;
	int CurYAxis ;

// Operations
public:
	int CalculateDataBound() ;
	int TrainingThread() ;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAIRDemoDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CAIRDemoDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CAIRDemoDoc)
	afx_msg void OnTrainingProcess();
	afx_msg void OnTrainingTree();
	afx_msg void OnTrain();
	afx_msg void OnUpdateTrain(CCmdUI* pCmdUI);
	afx_msg void OnStepTraining();
	afx_msg void OnUpdateStepTraining(CCmdUI* pCmdUI);
	afx_msg void OnStop();
	afx_msg void OnUpdateStop(CCmdUI* pCmdUI);
	afx_msg void OnAddNeuron();
	afx_msg void OnUpdateAddNeuron(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTrainingProcess(CCmdUI* pCmdUI);
	afx_msg void OnUpdateTrainingTree(CCmdUI* pCmdUI);
	afx_msg void OnRedistributeWeight();
	afx_msg void OnUpdateRedistributeWeight(CCmdUI* pCmdUI);
	afx_msg void OnDisplayUpperLayer();
	afx_msg void OnUpdateDisplayUpperLayer(CCmdUI* pCmdUI);
	afx_msg void OnDisplayLowerLayer();
	afx_msg void OnUpdateDisplayLowerLayer(CCmdUI* pCmdUI);
	afx_msg void OnAirAdd();
	afx_msg void OnUpdateAirAdd(CCmdUI* pCmdUI);
	afx_msg void OnRandomAdd();
	afx_msg void OnUpdateRandomAdd(CCmdUI* pCmdUI);
	afx_msg void OnChangeXAxis();
	afx_msg void OnUpdateChangeXAxis(CCmdUI* pCmdUI);
	afx_msg void OnChangeYAxis();
	afx_msg void OnUpdateChangeYAxis(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_AIRDEMODOC_H__7E3E70F6_8F83_45DB_9D2D_EF0F7654F8F0__INCLUDED_)
