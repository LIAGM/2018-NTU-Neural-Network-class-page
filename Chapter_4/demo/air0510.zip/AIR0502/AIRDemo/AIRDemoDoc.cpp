// AIRDemoDoc.cpp : implementation of the CAIRDemoDoc class
//

#include "stdafx.h"
#include "AIRDemo.h"

#include "AIRDemoDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAIRDemoDoc

IMPLEMENT_DYNCREATE(CAIRDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CAIRDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CAIRDemoDoc)
	ON_COMMAND(ID_TRAINING_PROCESS, OnTrainingProcess)
	ON_COMMAND(ID_TRAINING_TREE, OnTrainingTree)
	ON_COMMAND(ID_TRAIN, OnTrain)
	ON_UPDATE_COMMAND_UI(ID_TRAIN, OnUpdateTrain)
	ON_COMMAND(ID_STEP_TRAINING, OnStepTraining)
	ON_UPDATE_COMMAND_UI(ID_STEP_TRAINING, OnUpdateStepTraining)
	ON_COMMAND(ID_STOP, OnStop)
	ON_UPDATE_COMMAND_UI(ID_STOP, OnUpdateStop)
	ON_COMMAND(ID_ADD_NEURON, OnAddNeuron)
	ON_UPDATE_COMMAND_UI(ID_ADD_NEURON, OnUpdateAddNeuron)
	ON_UPDATE_COMMAND_UI(ID_TRAINING_PROCESS, OnUpdateTrainingProcess)
	ON_UPDATE_COMMAND_UI(ID_TRAINING_TREE, OnUpdateTrainingTree)
	ON_COMMAND(ID_REDISTRIBUTE_WEIGHT, OnRedistributeWeight)
	ON_UPDATE_COMMAND_UI(ID_REDISTRIBUTE_WEIGHT, OnUpdateRedistributeWeight)
	ON_COMMAND(ID_DISPLAY_UPPER_LAYER, OnDisplayUpperLayer)
	ON_UPDATE_COMMAND_UI(ID_DISPLAY_UPPER_LAYER, OnUpdateDisplayUpperLayer)
	ON_COMMAND(ID_DISPLAY_LOWER_LAYER, OnDisplayLowerLayer)
	ON_UPDATE_COMMAND_UI(ID_DISPLAY_LOWER_LAYER, OnUpdateDisplayLowerLayer)
	ON_COMMAND(ID_AIR_ADD, OnAirAdd)
	ON_UPDATE_COMMAND_UI(ID_AIR_ADD, OnUpdateAirAdd)
	ON_COMMAND(ID_RANDOM_ADD, OnRandomAdd)
	ON_UPDATE_COMMAND_UI(ID_RANDOM_ADD, OnUpdateRandomAdd)
	ON_COMMAND(ID_CHANGE_X_AXIS, OnChangeXAxis)
	ON_UPDATE_COMMAND_UI(ID_CHANGE_X_AXIS, OnUpdateChangeXAxis)
	ON_COMMAND(ID_CHANGE_Y_AXIS, OnChangeYAxis)
	ON_UPDATE_COMMAND_UI(ID_CHANGE_Y_AXIS, OnUpdateChangeYAxis)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAIRDemoDoc construction/destruction

UINT ChildThread(LPVOID param)
{
	CAIRDemoDoc *pDoc = (CAIRDemoDoc* ) param;
	// training 
	return pDoc->TrainingThread() ;
}

CAIRDemoDoc::CAIRDemoDoc()
{
	// TODO: add one-time construction code here
	bp = new AIR_BP ;

	// default configuration
	CurXAxis = 0 ;
	CurYAxis = 1 ;
	CurInputLayer = 0 ; // Input layer
	CurConflictLayer = 1 ; // Input Layer + 1 
	DataBound.left = DataBound.bottom = 0 ;
	DataBound.right = DEFAULT_WIDTH ;
	DataBound.top = DEFAULT_HEIGHT ;

	E = 0.0 ;

	m_UI_training = FALSE ;	// initial, trainable - non-stopale ;

	display_mode = Process ;
	srand(time(NULL)) ;
}

CAIRDemoDoc::~CAIRDemoDoc()
{
	if ( bp ){ 
		delete bp ;
		bp = 0 ;
	}

}

BOOL CAIRDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CAIRDemoDoc serialization

void CAIRDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CAIRDemoDoc diagnostics

#ifdef _DEBUG
void CAIRDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CAIRDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CAIRDemoDoc commands

BOOL CAIRDemoDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;
	
	// TODO: Add your specialized creation code here

	// blindly assume the file is right ; dangerous
	if( ! bp->Load( lpszPathName ) ) 
		return FALSE ;

	// calculate the boundary of data
	CalculateDataBound() ;

	return TRUE;
}

int CAIRDemoDoc::TrainingThread(){

	const int epoch_length = 100 ;
	int epoch = 0 ;

	do {	// Loop to training

		if( epoch == epoch_length ) {
			epoch = 0 ;
			// mode 0 does not perform masking operation 
			CurConflictLayer = bp->AmbiguityTest(0) ;
		}




		E = bp->Train() ;
		POSITION pos = GetFirstViewPosition();
		GetNextView(pos)->Invalidate() ;

		epoch ++ ;

	} while ( (::WaitForSingleObject(m_Stop_Event.m_hObject,0) != WAIT_OBJECT_0) );

	m_Stop_Event.ResetEvent();
	m_UI_training = FALSE;

	return 1; 
}

int CAIRDemoDoc::CalculateDataBound(){
	int i;
	double * p ;

	p = bp->Sim2(CurInputLayer, 0)  ;

	DataBound.left = DataBound.right = p[CurXAxis] ;
	DataBound.bottom = DataBound.top = p[CurYAxis] ;

	for( i = 1 ; i < bp->GetNumPat() ; i++ ){
		
		p = bp->Sim2(CurInputLayer, i) ;

		if( p[CurXAxis] < DataBound.left )
			DataBound.left = p[CurXAxis] ;
		else if( p[CurXAxis] > DataBound.right )
			DataBound.right = p[CurXAxis] ;

		if( p[CurYAxis] > DataBound.top ) 
			DataBound.top = p[CurYAxis] ;
		else if( p[CurYAxis] < DataBound.bottom ) 
			DataBound.bottom = p[CurYAxis] ;
	}

	double w = DataBound.right - DataBound.left ;
	double h = DataBound.top - DataBound.bottom ;
	double ratio = 0.1f ;
	DataBound.left -= (w*ratio) ;
	DataBound.right += (w*ratio) ;
	DataBound.bottom -= (h*ratio) ;
	DataBound.top += (h*ratio) ;

	// modify to fit the size of window

	return 1; 
}

void CAIRDemoDoc::OnTrain() 
{
	// TODO: Add your command handler code here
	m_UI_training = TRUE ;
	AfxBeginThread(ChildThread, (LPVOID) this ) ;
}

void CAIRDemoDoc::OnUpdateTrain(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( !m_UI_training && bp->Loaded() ) ;
}

void CAIRDemoDoc::OnStepTraining() 
{
	// TODO: Add your command handler code here
	m_UI_training = TRUE ;	
	m_Stop_Event.SetEvent();
	AfxBeginThread(ChildThread,(LPVOID)this,THREAD_PRIORITY_NORMAL);
}

void CAIRDemoDoc::OnUpdateStepTraining(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( !m_UI_training && bp->Loaded() ) ;	
}

void CAIRDemoDoc::OnStop() 
{
	// TODO: Add your command handler code here
	m_Stop_Event.SetEvent() ;
}

void CAIRDemoDoc::OnUpdateStop(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( m_UI_training && bp->Loaded() ) ;		
}

void CAIRDemoDoc::OnAddNeuron() 
{
	// TODO: Add your command handler code here
	bp->add_neuron(1, CurInputLayer+1 ) ;
	UpdateAllViews(NULL) ;
}

void CAIRDemoDoc::OnUpdateAddNeuron(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bp->Loaded() && ! m_UI_training && CurInputLayer == CurConflictLayer - 1) ;	
}


void CAIRDemoDoc::OnTrainingProcess() 
{
	// TODO: Add your command handler code here
	display_mode = Process ;
	UpdateAllViews(NULL) ;
}

void CAIRDemoDoc::OnTrainingTree() 
{
	// TODO: Add your command handler code here
	display_mode = Tree ;
	bp->BuildTree() ;
	UpdateAllViews(NULL) ;
}

void CAIRDemoDoc::OnUpdateTrainingProcess(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bp->Loaded() && display_mode == Tree ) ;	
}

void CAIRDemoDoc::OnUpdateTrainingTree(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bp->Loaded() && display_mode == Process ) ;	
}

void CAIRDemoDoc::OnRedistributeWeight() 
{
	// TODO: Add your command handler code here
	// default configuration
	CurXAxis = 0 ;
	CurYAxis = 1 ;
	CurInputLayer = 0 ; // Input layer
	CurConflictLayer = 1 ; // Input Layer + 1 

	bp->ReDistribute(1.0) ;
	CalculateDataBound() ;
	UpdateAllViews(NULL) ;
}

void CAIRDemoDoc::OnUpdateRedistributeWeight(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bp->Loaded() ) ;
}

void CAIRDemoDoc::OnDisplayUpperLayer() 
{
	// TODO: Add your command handler code here
	CurInputLayer++ ;
	CurXAxis = 0 ;
	CurYAxis = 1 ;
	CalculateDataBound() ;
	UpdateAllViews(NULL) ;
}

void CAIRDemoDoc::OnUpdateDisplayUpperLayer(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bp->Loaded() && CurInputLayer < CurConflictLayer - 1 && CurInputLayer < bp->GetLayer() - 1 ) ;
}

void CAIRDemoDoc::OnDisplayLowerLayer() 
{
	// TODO: Add your command handler code here
	CurInputLayer-- ;
	CurXAxis = 0 ;
	CurYAxis = 1 ;
	CalculateDataBound() ;
	UpdateAllViews(NULL) ;
}

void CAIRDemoDoc::OnUpdateDisplayLowerLayer(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bp->Loaded() && CurInputLayer > 0 ) ;	
}

void CAIRDemoDoc::OnAirAdd() 
{
	// TODO: Add your command handler code here
	bp->SetAddNeuronMode( AIR_BP::AddNeuronMode::AIR ) ;
}

void CAIRDemoDoc::OnUpdateAirAdd(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bp->Loaded() ) ;
	pCmdUI->SetCheck( bp->GetAddNeuronMode() == AIR_BP::AddNeuronMode::AIR ) ;
}

void CAIRDemoDoc::OnRandomAdd() 
{
	// TODO: Add your command handler code here
	bp->SetAddNeuronMode( AIR_BP::AddNeuronMode::Random ) ;
}

void CAIRDemoDoc::OnUpdateRandomAdd(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bp->Loaded() ) ;
	pCmdUI->SetCheck( bp->GetAddNeuronMode() == AIR_BP::AddNeuronMode::Random ) ;	
}

void CAIRDemoDoc::OnChangeXAxis() 
{
	// TODO: Add your command handler code here
	CurXAxis++ ;
	while( 1 ){
		if( CurXAxis == CurYAxis ) 
			CurXAxis++ ;
		else if( CurXAxis == bp->GetNumNeuron(CurInputLayer) )
			CurXAxis = 0 ;
		else 
			break ;
	}
	UpdateAllViews(NULL) ;
}

void CAIRDemoDoc::OnUpdateChangeXAxis(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bp->Loaded() && bp->GetNumNeuron(CurInputLayer) > 2) ;
}

void CAIRDemoDoc::OnChangeYAxis() 
{
	// TODO: Add your command handler code here
	CurYAxis++ ;
	while( 1 ){ 
		if( CurYAxis == CurXAxis ) 
			CurYAxis++ ;
		else if( CurYAxis == bp->GetNumNeuron(CurInputLayer) ) 
			CurYAxis = 0 ;
		else 
			break; 
	}
	UpdateAllViews(NULL) ;
}

void CAIRDemoDoc::OnUpdateChangeYAxis(CCmdUI* pCmdUI) 
{
	// TODO: Add your command update UI handler code here
	pCmdUI->Enable( bp->Loaded() && bp->GetNumNeuron(CurInputLayer) > 2) ;	
}
