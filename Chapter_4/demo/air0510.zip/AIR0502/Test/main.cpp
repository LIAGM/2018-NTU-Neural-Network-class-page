#include <stdio.h>
#include <conio.h>

#include "../BPSystem/AIR_BP.h"
AIR_BP * bp ;

int main(void){

	char c ;
	double E ;
	int count ;


	count = 0 ;
	bp = new AIR_BP ;
	bp->Load("../Data/p62.txt") ;

	while(1) {
		E = bp->Train() ;	

		printf("Error %lf\n", E) ;
		if( count == 10 ) {
			count = 0 ;
			c = _getch() ;
			if( c == 'r' )
				bp->ReDistribute(0.1) ;
			else if( c == 'a' ) 
				bp->add_neuron(1, 1) ;
			else if( c == 'q' ) 
				break; 
		}
		else count++ ;

	}

 	delete bp ;

	bp = 0 ;
	return 0 ;

}