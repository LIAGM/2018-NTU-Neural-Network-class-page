#ifndef __FMS_SYSTEM__
#define __FMS_SYSTEM__

#include "SuperviseSystem.h"
class FMSSystem : public SuperviseSystem {
public:
	FMSSystem() ;
	virtual ~FMSSystem() ;

	virtual int Load(const char* filename) ;
	virtual double Train() ;
	virtual int PreInit() ;

	void EnablePrune();
	void DisablePrune();
	int IsAlive(int i, int j, int k) ;
	int NumPruned(int layer) ;

protected:

	virtual int DestroyBP() ;
	double **** ykw; // dy^k/dW_ij [output_neuron][all synapse]
	double **** b;  // d b^k/d W_ij [output_neuron][all synapse]

	double *** rs;  // R{s[u][i]} [output_neuron][layer][neuron]
	double *** ry;  // R{y[u][i]} [output_neuron][layer][neuron]
	double *** ks;	// dy^k/ds^i [output_neuron][layer][neuron]
	double *** ky;  // dy^k/dy^i [output_neuron][layer][neuron]
	double ** rdks;  // R{d y^k/d s^i} [layer][neuron]
	double ** rdky;  // R{d y^k/d y^i} [layer][neuron]

	double *** rdw; //for all synapse
	double *** yw;  // dE/dW_ij  the gradient of the quadratic error for every synapse
	double *** t1;  // sum_(output)(ykw[i][j])
	double * t2;  // for all output neuron ;
	int *** alive; // synapse
	int *** wasalive; 
	int *** insignificant; // synapse
	double *** sigmaWeight; // for all synapse

	double K, E, Ea, Eo, En, Etol ;
	double epsilon, gamma, sigma ;
	double sigmaMin ;
	double lambda, delta_lambda ;
	int num_output ;
	int exemplars, epochs, epochlength;

	// prune
	int prune_flag ;
	
};

inline void FMSSystem::EnablePrune(){
	prune_flag = 1 ;
}

inline void FMSSystem::DisablePrune(){
	prune_flag = 0 ;
}

inline int FMSSystem::IsAlive(int i, int j, int k){
	return alive[i][j][k] ;
}

#endif