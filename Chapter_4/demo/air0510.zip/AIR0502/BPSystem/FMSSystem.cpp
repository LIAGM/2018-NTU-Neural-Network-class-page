#include "FMSSystem.h"
#include <stdlib.h>

#define SIGN(x) ( (x) >= 0 ? 1 : -1 )
#define KRON(x,y) ( (x) == (y) ? 1 : 0 )

FMSSystem::FMSSystem():SuperviseSystem(){
}

FMSSystem::~FMSSystem(){
	DestroyBP() ;
}

int FMSSystem::PreInit(){
	int i, j, k ;

	if( !DataPresent )
		return 0;
	
	K = 1000 ;
	epsilon = 1.0e-5;
	exemplars = epochs = 0 ;
	epochlength = num_pat ;
	ReDistribute(1) ;
	// learn rate is already set
	lambda = 0.0 ;
	gamma = 0.85 ;
	sigma = 0.5 ;
	delta_lambda = 0.001 * learn_rate ;
	Etol = 0.0016 ;
	E = Ea = Eo = En = 0.0 ;

	if( alive && wasalive ){
	for( i = 0 ; i < num_layer ; i++ )
		for( j = 0 ; j < neuron[i+1] ; j++ )
			for( k = 0 ; k < neuron[i]+1 ; k++ ){
				alive[i][j][k] = 1 ;
				wasalive[i][j][k] = 0 ;
			}
	}

	sigmaMin = 1.0e5;
	prune_flag = 1 ;

	return SuperviseSystem::PreInit() ;
}

int FMSSystem::DestroyBP(){
	int i, j, k;
	
	if( !DataPresent )
		return 0 ;

	delete [] t2 ;
	t2 = 0 ;

	for( j = 0 ; j < num_layer+1 ; j++ ){
		delete [] rdks[j] ;
		delete [] rdky[j] ;
	}
	delete [] rdks ;
	delete [] rdky ;

	// [output_neuron][layer+1][neuron of layer]
	for( i = 0 ; i < num_output ; i++ ){
		for( j = 0 ; j < num_layer+1 ; j++ ){
			delete [] ks[i][j] ;
			delete [] ky[i][j] ;
			delete [] rs[i][j] ;
			delete [] ry[i][j] ;
		}
		delete [] ks[i] ;
		delete [] ky[i] ;
		delete [] rs[i] ;
		delete [] ry[i] ;
	}
	delete [] ks ;
	delete [] ky ;
	delete [] rs ;
	delete [] ry ;
	ks = ky = rs = ry = 0;
	rdks = rdky = 0 ;

	// for all synapse
	for( i = 0 ; i < num_layer ; i++ ){
		for( j = 0 ; j < neuron[i+1] ; j++ ){
			delete [] rdw[i][j];
			delete [] yw[i][j] ;
			delete [] t1[i][j] ;
			delete [] sigmaWeight[i][j] ;
			delete [] alive[i][j] ;
			delete [] wasalive[i][j] ;
			delete [] insignificant[i][j] ;
		}
		delete [] rdw[i] ;
		delete [] yw[i] ;
		delete [] t1[i] ;
		delete [] sigmaWeight[i] ;
		delete [] alive[i] ;
		delete [] wasalive[i] ;
		delete [] insignificant[i] ;
	}
	delete [] rdw ;
	delete [] yw ;
	delete [] t1 ;
	delete [] sigmaWeight ;
	delete [] alive ;
	delete [] wasalive ;
	delete [] insignificant ;
	
	rdw = yw = t1 = sigmaWeight = 0 ;
	alive = wasalive = insignificant = 0 ;


	for( k = 0 ; k < num_output ; k++ ){
		for( i = 0 ; i < num_layer ; i++ ){
			for( j = 0 ; j < neuron[i+1] ; j++ ){
				delete [] ykw[k][i][j] ;
				delete [] b[k][i][j] ;
			}
			delete [] ykw[k][i] ;
			delete [] b[k][i] ;
		}
		delete [] ykw[k] ;
		delete [] b[k] ;
	}
	delete [] ykw ;
	delete [] b ;

	ykw = b = 0 ;

	return SuperviseSystem::DestroyBP() ;
}

int FMSSystem::Load(const char* filename){
	int r;
	int i, j, k;
	r = SuperviseSystem::Load(filename) ;
	
	if( r ) {
		num_output = neuron[num_layer] ;
		
		// for all output neuron
		t2 = new double [num_output] ;
		
		// [output_neuron][layer+1][neuron of layer]
		ks = new double** [num_output] ;
		ky = new double** [num_output] ;
		rs = new double** [num_output] ;
		ry = new double** [num_output] ;


		for( i = 0 ; i < num_output ; i++ ){
			ks[i] = new double* [num_layer+1] ;
			ky[i] = new double* [num_layer+1] ;
			rs[i] = new double* [num_layer+1] ;
			ry[i] = new double* [num_layer+1] ;
			rdks = new double* [num_layer+1] ;
			rdky = new double* [num_layer+1] ;
			for( j = 0 ; j < num_layer+1 ; j++ ){
				ks[i][j] = new double [neuron[j]+1] ;
				ky[i][j] = new double [neuron[j]+1] ;
				rs[i][j] = new double [neuron[j]+1] ;
				ry[i][j] = new double [neuron[j]+1] ;
				rdks[j] = new double [neuron[j]+1] ;
				rdky[j] = new double [neuron[j]+1] ;
			}
		}

		// for all synapse
		rdw = new double** [num_layer];
		yw = new double** [num_layer];
		t1 = new double** [num_layer];
		sigmaWeight = new double** [num_layer];
		alive = new int** [num_layer];
		wasalive = new int** [num_layer];
		insignificant = new int** [num_layer];
		for( i = 0 ; i < num_layer ; i++ ){
			rdw[i] = new double* [neuron[i+1]] ;
			yw[i] = new double* [neuron[i+1]] ;
			t1[i] = new double* [neuron[i+1]] ;
			sigmaWeight[i] = new double* [neuron[i+1]] ;
			alive[i] = new int* [neuron[i+1]] ;
			wasalive[i] = new int* [neuron[i+1]] ;
			insignificant[i] = new int* [neuron[i+1]] ;
			for( j = 0 ; j < neuron[i+1] ; j++ ){
				rdw[i][j] = new double[neuron[i]+1] ;
				yw[i][j] = new double[neuron[i]+1] ;
				t1[i][j] = new double[neuron[i]+1] ;
				sigmaWeight[i][j] = new double[neuron[i]+1] ;
				alive[i][j] = new int[neuron[i]+1] ;
				wasalive[i][j] = new int[neuron[i]+1] ;
				insignificant[i][j] = new int[neuron[i]+1] ;
			}
		}

		ykw = new double*** [num_output] ;		// weight
		b = new double*** [num_output] ;
		for( k = 0 ; k < num_output ; k++ ){
			ykw[k] = new double** [num_layer] ;
			b[k] = new double** [num_layer] ;
			for( i = 0 ; i < num_layer ; i++ ){
				ykw[k][i] = new double * [neuron[i+1]] ;
				b[k][i] = new double * [neuron[i+1]] ;
				for( j = 0 ; j < neuron[i+1] ; j++ ){
					ykw[k][i][j] = new double [neuron[i]+1] ;
					b[k][i][j] = new double [neuron[i]+1] ;
				}
			}
		}

		PreInit() ;
	}

	return r ;
}

// implementation of schmidhuber FMS
double FMSSystem::Train(){
	int i, j, k, m, n, p, u;
	int src_layer, dest_layer ;
	double E, t3, t4;
	double lyw, lrdw, scale ;
	double prune_bound = 1.0e-5 ;
	int Weights ;


	double temp, temp2 ;

	// schmidhuber algo variables
	E = 0.0 ;

	// shuffle
	for( i = 0 ; i < num_pat ; i++ ){
		j = rand() % num_pat ;
		k = index[i] ;
		index[i] = index[j];
		index[j] = k;
	}

	for( n = 0 ; n < num_pat ; n++ ){	// for all pattern
		p = index[n] ;

		if( n % 100 == 0 ) {
			int temp ;
			temp = 0 ;
		}

		///////////////////////////////////////////////////////
		// Necessary Initialization for each input pattern Here
		///////////////////////////////////////////////////////
		
		// 1. for every synapse,  yw, t1
		for( i = 0 ; i < num_layer ; i++ )
			for( j = 0 ; j < neuron[i+1] ; j++ )
				for( k = 0 ; k < neuron[i]+1 ; k++ ){
					rdw[i][j][k] = yw[i][j][k] = t1[i][j][k] = 0.0 ;
					insignificant[i][j][k] = 0 ;

				}

		// 2. for [output][layer][neuron]
		for( i = 0 ; i < num_output ; i++ )
			for( j = 0 ; j <= num_layer ; j++ )
				for( k = 0 ; k < neuron[j] ; k++ ){
					ky[i][j][k] = 0.0 ;
					rs[i][j][k] = 0.0 ;
					rdky[j][k] = 0.0 ;
				}

		// 3. others
		E = 0.0 ;
		


		////////////////////////////////
		// End of Initialization
		////////////////////////////////

		///////////////////////////		
		// forward pass
		///////////////////////////		
		for( j = 0 ; j < neuron[0] ; j++ )	// copy input
			X[0][j] = Input[p][j] ;			// bias is already set to 1 while loading

		for( u = 0 ; u < num_layer ; u++ ){
			src_layer = u ;
			dest_layer = u+1 ;
			for( i = 0 ; i < neuron[dest_layer] ; i++ ){
				S[dest_layer][i] = 0.0 ;
				for( j = 0 ; j <= neuron[src_layer] ; j++ )
					S[dest_layer][i] += Weight[src_layer][i][j] * X[src_layer][j] ;
				Eval_AC(X[dest_layer][i], S[dest_layer][i], activation[dest_layer]) ;

			}
		}
		///////////////////////////		
		// end of forward pass
		///////////////////////////		

		///////////////////////////		
		// Error Computation
		///////////////////////////		
		for( k = 0 ; k < num_output ; k++ )
			E += (0.5*dpow(Desire[p][k] - X[num_layer][k], 2)) ;
		
		En += E ;

		///////////////////////////		
		// Backward pass
		///////////////////////////		
		for( k = 0 ; k < num_output ; k++ ){	// for all output neuron 

			Eval_DifAC(ks[k][num_layer][k], S[num_layer][k], activation[num_layer]) ;

			for( u = 1 ; u <= num_layer ; u++ ){	// for all layers from output-1 to input
				src_layer = num_layer - u ;
				dest_layer = src_layer + 1;
				for( j = 0 ; j < neuron[src_layer]+1 ; j++ ){
					if( u != 1 ){
						for( i = 0 ; i < neuron[dest_layer] ; i++ ){
							if( alive[src_layer][i][j] ){
								ykw[k][src_layer][i][j] = X[src_layer][j] * ks[k][dest_layer][i] ;
								if( ykw[k][src_layer][i][j] < 1.0e-5 ) 
									ykw[k][src_layer][i][j] = 1.0e-5 ;
								yw[src_layer][i][j] += ykw[k][src_layer][i][j] * (Desire[p][k]-X[num_layer][k]) ;
								ky[k][src_layer][j] += Weight[src_layer][i][j]* ks[k][dest_layer][i] ;
								t1[src_layer][i][j] += dpow(ykw[k][src_layer][i][j], 2) ;
							}
						}
					}
					else{
						i = k ;
						if( alive[src_layer][i][j] ){
							ykw[k][src_layer][i][j] = X[src_layer][j] * ks[k][dest_layer][i] ;
							if( ykw[k][src_layer][i][j] < 1.0e-5 ) 
								ykw[k][src_layer][i][j] = 1.0e-5 ;
							yw[src_layer][i][j] += ykw[k][src_layer][i][j] * (Desire[p][k]-X[num_layer][k]) ;
							ky[k][src_layer][j] += Weight[src_layer][i][j]* ks[k][dest_layer][i] ;
							t1[src_layer][i][j] += dpow(ykw[k][src_layer][i][j], 2) ;
						}

					}
					if( src_layer != 0 ){
						Eval_DifAC(ks[k][src_layer][j], S[src_layer][j], activation[src_layer] );
						ks[k][src_layer][j] *= ky[k][src_layer][j] ;
					}
				}
			}
		}
		///////////////////////////		
		// End of Backward pass
		///////////////////////////

		///////////////////////////
		// Compute b[k][i][j]
		///////////////////////////

		// 1. t2 and t3 
		t3 = 0.0 ;
		for( k = 0 ; k < num_output ; k++ ) {
			t2[k] = 0.0 ;
			for( u = 0 ; u < num_layer ; u++ ){
				src_layer = u ;
				dest_layer = u+1 ;
				for( i = 0 ; i < neuron[dest_layer] ; i++ )
					for( j = 0 ; j < neuron[src_layer]+1 ; j++ )
						if( alive[src_layer][i][j] )
							t2[k] += fabs(ykw[k][src_layer][i][j]) / sqrt(t1[src_layer][i][j]) ;
			}
			t3 += t2[k]*t2[k] ;
		}

		// 2. some weights are significant
		for( u = 0 ; u < num_layer ; u++ ){
			src_layer = u ;
			dest_layer = src_layer+1 ;
			for( i = 0 ; i < neuron[dest_layer] ; i++ )
				for( j = 0 ; j < neuron[src_layer]+1 ; j++ ){
					if( alive[src_layer][i][j] ){
						sigmaWeight[src_layer][i][j] = sqrt( epsilon / ( t1[src_layer][i][j] * t3 )) ;
						if( sigmaWeight[src_layer][i][j] < sigmaMin ) 
							sigmaMin = sigmaWeight[src_layer][i][j] ;
					}
				}
		}

		Weights = 0 ;

		for( u = 0 ; u < num_layer ; u++ )
			for( i = 0 ; i < neuron[u+1] ; i++ )
				for( j = 0 ; j < neuron[u]+1 ; j++ )
					if( alive[u][i][j] ){
						if( sigmaWeight[u][i][j] > K*sigmaMin || fabs(sigmaWeight[u][i][j]) < prune_bound ) {
							insignificant[u][i][j] = 1 ;
							for( k = 0 ; k < num_output ; k++ )
								t1[u][i][j] -= dpow(ykw[k][u][i][j], 2) ;
						}
						else{
							Weights++ ;
							wasalive[u][i][j] = 1 ;
						}
					}

		///////////////////
		// update variables
		///////////////////
		t3 = 0.0 ;
		for( k = 0 ; k < num_output ; k++ ){
			t2[k] = 0.0 ;
			for( u = 0 ; u < num_layer ; u++ )
				for( i = 0 ; i < neuron[u+1] ; i++ )
					for( j = 0 ; j < neuron[u]+1 ; j++ ){
						if( alive[u][i][j] && !insignificant[u][i][j] )
							t2[k] += fabs(ykw[k][u][i][j]) / sqrt(t1[u][i][j]) ;
					}

			t3 += t2[k]*t2[k] ;
		}

		for( k = 0 ; k < num_output ; k++ )
			for( u = 0 ; u < num_layer ; u++ )
				for( i = 0 ; i < neuron[u+1] ; i++ )
					for( j = 0 ; j < neuron[u]+1 ; j++ )
						if( alive[u][i][j] && !insignificant[u][i][j] ){
							t4 = 0.0 ;
							for( m = 0 ; m < num_output ; m++ )
								t4 += t2[m] * SIGN(ykw[m][u][i][j]) * 
								     (KRON(m,k)*t1[u][i][j] - ykw[m][u][i][j]*ykw[k][u][i][j] ) /
									 sqrt(dpow(t1[u][i][j], 3)) ;
							b[k][u][i][j] = ykw[k][u][i][j] / t1[u][i][j] + Weights*t4/t3 ;
						}
			
		//////////////////////////
		//End of computing B
		//////////////////////////		

		//////////////////////////
		//Forward pass
		//////////////////////////
		for( k = 0 ; k < num_output ; k++ ){

			for( j = 0 ; j <= neuron[0] ; j++ )
				ry[k][0][j] = 0.0;

			for( u = 1 ; u <= num_layer ; u++ ){
				src_layer = u - 1;
				dest_layer = u ;
				if( u != num_layer ){
					for( i = 0 ; i < neuron[dest_layer] ; i++ ){
						for( j = 0 ; j < neuron[src_layer]+1 ; j++ )
							if( alive[src_layer][i][j] && !insignificant[src_layer][i][j] )
								rs[k][dest_layer][i] += Weight[src_layer][i][j]*ry[k][src_layer][j] + b[k][src_layer][i][j]*X[src_layer][j] ;

						Eval_DifAC(temp, S[dest_layer][i], activation[dest_layer]) ;
						ry[k][dest_layer][i] = rs[k][dest_layer][i] * temp ;
					}
				}
				else {
					i = k ;
					for( j = 0 ; j < neuron[src_layer]+1 ; j++ )
						if( alive[src_layer][i][j] && !insignificant[src_layer][i][j] )
							rs[k][dest_layer][i] += Weight[src_layer][i][j]*ry[k][src_layer][j] + b[k][src_layer][i][j]*X[src_layer][j] ;

					Eval_DifAC(temp, S[dest_layer][i], activation[dest_layer]) ;
					ry[k][dest_layer][i] = rs[k][dest_layer][i] * temp ;
				}
			}
		}
		///////////////////////////
		// Second Backward pass
		///////////////////////////
		for( k = 0 ; k < num_output ; k++ ){
			Eval_Dif2AC(rdks[num_layer][k] ,S[num_layer][k], activation[num_layer]) ;
			rdks[num_layer][k] *= rs[k][num_layer][k] ;
			for( u = 1 ; u <= num_layer ; u++ ){
				src_layer = num_layer - u ;
				dest_layer = src_layer+1 ;
				for( j = 0 ; j < neuron[src_layer]+1 ; j++ ){
					rdky[src_layer][j] = 0.0 ;
					if( u != 1 ){
						for( i = 0 ; i < neuron[dest_layer] ; i++ )
							if( alive[src_layer][i][j] && !insignificant[src_layer][i][j] ){
								rdky[src_layer][j] += Weight[src_layer][i][j] * rdks[dest_layer][i] + 
														b[k][src_layer][i][j] * ks[k][dest_layer][i] ;
								rdw[src_layer][i][j] += X[src_layer][j] * rdks[dest_layer][i] +
														ry[k][src_layer][j] * ks[k][dest_layer][i] ;
							}
					}
					else{
						i = k ;
						if( alive[src_layer][i][j] && !insignificant[src_layer][i][j] ){
							rdky[src_layer][j] += Weight[src_layer][i][j] * rdks[dest_layer][i] + 
													b[k][src_layer][i][j] * ks[k][dest_layer][i] ;
							rdw[src_layer][i][j] += X[src_layer][j] * rdks[dest_layer][i] +
													ry[k][src_layer][j] * ks[k][dest_layer][i] ;
						}
					}
					if( src_layer != 0 ){
					Eval_DifAC(temp, S[src_layer][j], activation[src_layer]) ;
					Eval_Dif2AC(temp2, S[src_layer][j], activation[src_layer]) ;
					rdks[src_layer][j] = temp*rdky[src_layer][j] + rs[k][src_layer][j] * temp2*ky[k][src_layer][j] ;
					}
				}
			}
		}

		// normalize B's gradient
		lyw = lrdw = 0.0 ;

		for( u = 0 ; u < num_layer ; u++ ){
			src_layer = u ;
			dest_layer = src_layer + 1 ;
			for( i = 0 ; i < neuron[dest_layer] ; i++ )
				for( j = 0 ; j < neuron[src_layer] + 1 ; j++ )
					if( alive[src_layer][i][j] && !insignificant[src_layer][i][j] ){
						lyw += dpow(yw[src_layer][i][j], 2);
						lrdw += dpow(rdw[src_layer][i][j], 2);
					}
		}

		scale = sqrt(lyw/lrdw) ;
		////////////////////////////////
		//End of second Back pass
		////////////////////////////////

		////////////////////////////////
		//Weight Update
		////////////////////////////////
		for( u = 0 ; u < num_layer ; u++ ){
			src_layer = u ;
			dest_layer = src_layer + 1 ;
			for( i = 0 ; i < neuron[dest_layer] ; i++ )
				for( j = 0 ; j < neuron[src_layer] + 1; j++ )
					if( alive[src_layer][i][j] && !insignificant[src_layer][i][j] ){
						Weight[src_layer][i][j] += learn_rate * yw[src_layer][i][j] -
												  lambda * scale * rdw[src_layer][i][j];

						// bounded weight
						if( Weight[src_layer][i][j] > 30.0 ) 
							Weight[src_layer][i][j] = 30.0 ; 
						else if( Weight[src_layer][i][j] < -30.0 )
							Weight[src_layer][i][j] = -30.0 ; 

					}
		}

		////////////////////////////////
		// End of Weight Update
		////////////////////////////////


		////////////////////////////////
		//Learning parameters Update
		////////////////////////////////
		exemplars++ ;

		if( exemplars % epochlength == 0 ){
			epochs++ ;
			En /= epochlength ;
			Ea = gamma * Ea + ( 1.0-gamma ) * En ;

			if( En <= Etol || En <= Eo )
				lambda += delta_lambda ;
			else{
				if( En <= Ea ){
					lambda -= delta_lambda ;
					if( lambda < 0.0 )
						lambda = 0.0 ;
				}
				else
					lambda *= sigma ;
			}

			Eo = En ;
			En = 0.0 ;

			// pruning can be enabled or disabled
			if( prune_flag ){
				// prune one synapse for each epoch
				int alive_flag = 1;
				for( u = 0 ; u < num_layer ; u++ ){
					src_layer = u ;
					dest_layer = src_layer+1 ;
					for( i = 0 ; i < neuron[dest_layer] ; i++ )
						for( j = 0 ; j < neuron[src_layer]+1 ; j++ ){
							if( wasalive[src_layer][i][j] == 0 && alive_flag ){
								alive_flag = 0;
								alive[src_layer][i][j] = 0 ;
							}
							wasalive[src_layer][i][j] = 0 ;
						}
				}
			}
			else{
				for( u = 0 ; u < num_layer ; u++ ){
					src_layer = u ;
					dest_layer = src_layer+1 ;
					for( i = 0 ; i < neuron[dest_layer] ; i++ )
						for( j = 0 ; j < neuron[src_layer]+1 ; j++ )
							wasalive[src_layer][i][j] = 0 ;
				}
			}

			// re-animate the synapse if the avg error is too large 
			// every 100 epochs, the synapse are revived, too.
			if( epochs % 500 == 0 || Eo > 2.0 * Etol ){
				for( u = 0 ; u < num_layer ; u++ ){
					src_layer = u ;
					dest_layer = src_layer+1 ;
					for( i = 0 ; i < neuron[dest_layer] ; i++ )
						for( j = 0 ; j < neuron[src_layer]+1 ; j++ ){
							if( !alive[src_layer][i][j] ){
//								alive[src_layer][i][j] = 1 ;
							}
								
						}
				}
			}
		}
	}
	return Ea ;
}

int FMSSystem::NumPruned(int layer){
	int i, j ;
	int sum = 0 ;
	for( i = 0 ; i < neuron[layer+1] ; i++ )
		for( j = 0 ; j < neuron[layer]+1 ; j++ )
			if( !alive[layer][i][j] ) 
				sum++ ;

	return sum ;
}

