#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "BPSystem.h"

BPSystem::BPSystem():SuperviseSystem(){

}

double BPSystem::Train() {
	int i, j, k, m, n ;
	double sum, E, temp ;
	
	// shuffle

	E = 0.0 ;

	for( i = 0 ; i < num_pat ; i++ ){
		j = rand() % num_pat ;

		k = index[i] ;
		index[i] = index[j];
		index[j] = k;
	}

	for( n = 0 ; n < num_pat ; n++ ){	// for all pattern
		i = index[n] ;

		// copy input to network
		for( j = 0 ; j < neuron[0] ; j++ )
			X[0][j] = Input[i][j] ;			// include bias, br careful

		// iteration to calculate hidden layer and output layer output

		// for all layers
		for( j = 1 ; j < num_layer + 1 ; j++ ){

			// for all neurons in layer j+1	( output )
			for( k = 0 ; k < neuron[j] ; k++ ){
				S[j][k] = 0.0 ;

				// for all neurons in layer j ( input ) 
				for( m = 0 ; m < neuron[j-1] + 1 ; m++ )		// include bias
					S[j][k] += Weight[j-1][k][m] * X[j-1][m] ; 
			

				Eval_AC(X[j][k], S[j][k], activation[j]) ;

				// hidden output, bipolar tanh
//				if( activation[j-1] == BITAN )
//					X[j][k] = alpha * tanh(beta * X[j][k]) ;

				// unipolar
//				else if( activation[j-1] == UNITAN )
//					X[j][k] = (alpha * tanh(beta* X[j][k]) + alpha) / 2 ;
			}
		}

		// now forward calculation is done. 


		// Error accumulation
		for( j = 0 ; j < neuron[num_layer] ; j++ )
			E += 0.5 * (Desire[i][j] - X[num_layer][j]) * (Desire[i][j] - X[num_layer][j]) ;


	
		// calculate output layer Error
		for( j = 0 ; j < neuron[num_layer] ; j++ ){
			temp = X[num_layer][j] ;
			
			if( activation[num_layer] == BITAN )
				Error[num_layer-1][j] = (Desire[i][j] - temp) * ( beta/alpha ) * ( alpha - temp ) * ( alpha + temp ) ;
			else if( activation[num_layer] == UNITAN )
				Error[num_layer-1][j] = (Desire[i][j] - temp) * 2 * ( beta / alpha ) * ( alpha - temp ) * temp ;
		}

		// BP algorithm
		for( j = num_layer - 1 ; j > 0 ; j-- ){
			for( k = 0 ; k < neuron[j] ; k++){
				sum = 0.0 ;

				for( m = 0 ; m < neuron[j+1] ; m++ )
					sum += Error[j][m] * Weight[j][m][k] ;

				temp = X[j][k] ;

				if( activation[j] == BITAN )
					Error[j-1][k] = sum * ( beta / alpha ) * ( alpha - temp ) * ( alpha + temp ) ;
				else if( activation[j] == UNITAN )
					Error[j-1][k] = sum * 2 * ( beta / alpha ) * ( alpha - temp ) * temp ;
			}
		}

		// update weight
		for( j = 0 ; j < num_layer; j++ )
			for( k = 0 ; k < neuron[j+1] ; k++ )
				for( m = 0 ; m < neuron[j]+1 ; m++ )
					Weight[j][k][m] += learn_rate * Error[j][k] * X[j][m];

	}

	return E ;
}

