#ifndef __NEURAL_TOOL_H__
#define __NEURAL_TOOL_H__

#include <vector>
#include <list>

double rand_weight(double scale) ;

enum NodeState{
	Pure, Conflict
} ;


typedef struct HammingTreeNode_S{

	int bitpat ;
	int desire ;
	int layer ;
	int sum_leaf ;
	struct HammingTreeNode_S * parent ;

	NodeState state ;
	
	double * pout ;
	std::vector< struct HammingTreeNode_S * > _list_child ;
	std::vector< int > _list_pattern ;


} HammingTreeNode ;

typedef struct AmbiguityNode_S {
	int bitpat ;	// bit pattern output of this node
	int desire ;	// desire of this tree ( if not conflict )
	int layer ;
	int sum_leaf ;
	double * pout ;	// out average

	NodeState state ;

//	union {
		std::vector< struct AmbiguityNode_S * > _list_child ;	// ptr to all the children, layer > 1
		std::vector< int > _list_pattern ;
//	} ;
	
} AmbiguityNode ;

double dpow(double x, int times) ;



#endif