#include <stdlib.h>
#include "Tool.h"

double rand_weight(double scale){
	int sign ;
	sign = rand() % 2 ;
	if( sign == 0 )
		sign = -1;
	return sign * ((double) rand()) / (RAND_MAX) * scale;	// random initial value	

}
double dpow(double x, int times){
	int inverse, i ;
	double product ;

	if( times == 0 ) 
		return 1.0 ;
	else if( times > 0 )
		inverse = 0 ;
	else {
		inverse = 1 ;
		times = -times ;
	}

	product = 1.0 ;
	for( i = 0 ; i < times ; i++ )
		product *= x ;

	if( inverse )
		product = 1/product ;

	return product ;
}