#ifndef SUPERVISE_SYSTEM
#define SUPERVISE_SYSTEM

#include <math.h>
#include "Tool.h"

typedef double (*ACFunc) (double value, double alpha, double beta) ;

#define Eval_AC(result, value, type) { result = acfunc[type](value, alpha, beta) ; } 
#define Eval_DifAC(result, value, type) { result = difacfunc[type](value, alpha, beta); }
#define Eval_Dif2AC(result, value, type) { result = dif2acfunc[type](value, alpha, beta); }

enum AC{
	PURELIN = 0,		// pure limit
	UNITAN,			// unipolar-hyperbolic-tangent
	BITAN,			// bipolar-hyperbolic-tangent
	UNISIG,			// unipolar-sigmoid
	BISIG			// bipolar-sigmoid
} ;

class SuperviseSystem {

public :

	SuperviseSystem() ;
	virtual ~SuperviseSystem() ;

	////////////////
	// pure virtual
	////////////////
	// return error
	virtual double Train() = 0;
	// Randomize Weight if available
	virtual int PreInit() ;
	// load pattern and info of network architecture
	virtual int Load(const char* filename) ;

	// from hidden to output
	int Sim1(double * in, double * output, int layer ) ;

	// from input to hidden
	double* Sim2(double * in, int layer) ;
	double* Sim2(int layer, int ipat) ;

	virtual int ReDistribute(double scale) ;

	// input layer is zero
	inline double ** GetWeight(int ilayer) ;
	inline int GetNumNeuron(int ilayer) ;
	inline double * GetInput(int i) ;
	inline double * GetDesire(int i) ;
	inline int GetLayer() ;	
	inline int GetNumPat() ;


	// Get Bit-pattern, depend on alpha, beta
	int GetPattern(int layer) ;
	int GetDesirePattern(int ipat) ;


	/////////////////////////
	// build the hamming tree
	/////////////////////////
	HammingTreeNode *  BuildTree() ;
	// draw the tree with OpenGL, although it is a bad design
	// but it spare many effort to prepare the final exam of
	// neuron network, sorry .
	// maybe revision someday . pp
	int DrawTree(double left, double right, double bot, double top) ;
	// free the tree node memory
	int DestroyTree(HammingTreeNode * root) ;

	int Loaded() ;

	// tree root
	HammingTreeNode * _proot ;

protected :

	virtual int DestroyBP() ;

	double *** Weight ;		// weight
	double ** X ;		// input, hidden layer output, output
	double ** S;	// sumation neuron input
	
	// Error[i] is error from layer i+1 to i, the length of Error[i] is neuron[i+1]
	double ** Error ;	// error signal of each neuron

	double ** Input ;	// Input Pattern
	double ** Desire;	// expected output

	double learn_rate, alpha, beta;

	int * neuron ;	// neuron num in every layer, bottom-up
	int * index  ;
	int num_layer ;
	int num_pat ;
	int DataPresent ;
	AC * activation ;

	// activation function 
	static ACFunc acfunc[5] ;
	static ACFunc difacfunc[5] ;
	static ACFunc dif2acfunc[5] ;
private :
}; 

inline double ** SuperviseSystem::GetWeight(int ilayer) { return Weight[ilayer] ;}
inline int SuperviseSystem::GetNumNeuron(int ilayer) { return neuron[ilayer]; }
inline double * SuperviseSystem::GetInput(int i) { return Input[i] ;}
inline double * SuperviseSystem::GetDesire(int i) { return Desire[i]; }
inline int SuperviseSystem::GetLayer(){ return num_layer ; }
inline int SuperviseSystem::GetNumPat(){ return num_pat ; }

inline double purelin(double value, double alpha, double beta){
	return value ; 
}
inline double unitan(double value, double alpha, double beta){
	return (alpha * tanh(beta* value) + alpha) / 2 ;
}

inline double bitan(double value, double alpha, double beta){
	return alpha * tanh(beta * value) ;
};

inline double unisig(double value, double alpha, double beta){
	return 1.0 / (1.0+exp(-alpha*value)) ;
}

inline double bisig(double value, double alpha, double beta){
	return ( 1.0 / (1.0+exp(-alpha*value)) - 0.5 ) * 2 ;
}

inline double dpurelin(double value, double alpha, double beta){
	return 1.0 ; 
}
inline double dunitan(double value, double alpha, double beta){
//	return 2*(beta/alpha)*(alpha-value)*value ;
	return 2 * (beta/alpha) * (alpha - unitan(value, alpha, beta)) * unitan(value, alpha, beta);
}

inline double dbitan(double value, double alpha, double beta){
//	return (beta/alpha)*(alpha-value)*(alpha+value) ;
	return (beta/alpha)*(alpha-bitan(value, alpha, beta))*(alpha+bitan(value, alpha, beta)) ;
};

inline double dunisig(double value, double alpha, double beta){
	return alpha * (1.0 - 1.0/(1.0+exp(-alpha*value))) ;
}

inline double dbisig(double value, double alpha, double beta){
	return 2 * alpha * (1.0 - 1.0/(1.0+exp(-alpha*value))) ;
}

inline double d2purelin(double value, double alpha, double beta){
	return 0.0 ; 
}
inline double d2unitan(double value, double alpha, double beta){
	return 2 * (beta/alpha) * (alpha-2*unitan(value, alpha, beta)) * dunitan(value, alpha, beta);
}

inline double d2bitan(double value, double alpha, double beta){
	return -2*(beta/alpha) * bitan(value, alpha, beta) * dbitan(value, alpha, beta) ;
};

inline double d2unisig(double value, double alpha, double beta){
	return - alpha*alpha * (1.0 - 1.0/(1.0+exp(-alpha*value))) ;
}

inline double d2bisig(double value, double alpha, double beta){
	return -2 * alpha*alpha * (1.0 - 1.0/(1.0+exp(-alpha*value))) ;
}


inline int SuperviseSystem::Loaded() { return DataPresent ; }
#endif