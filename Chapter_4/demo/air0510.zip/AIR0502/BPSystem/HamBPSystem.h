#ifndef __HAM_BPSYS__
#define __HAM_BPSYS__

#include <vector>
#include <list>

#include "BPSystem.h"

class HamBPSystem : public BPSystem {

public : 
	HamBPSystem() ;
	~HamBPSystem() ;

	// build the hamming tree
	HammingTreeNode *  BuildTree() ;

	// draw the tree with OpenGL, although it is a bad design
	// but it spare many effort to prepare the final exam of
	// neuron network, sorry .
	// maybe revision someday . pp
	int DrawTree(double left, double right, double bot, double top) ;

	// free the tree node memory
	int DestroyTree(HammingTreeNode * root) ;

	int Load(const char* filename) ;

	inline HammingTreeNode *  GetTree() ;
private :

	HammingTreeNode * _proot ;

};


inline 
HammingTreeNode *  
HamBPSystem::
GetTree(){
	return _proot ; 
}

#endif