#include <vector>
#include <queue>	
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "SuperviseSystem.h"

ACFunc SuperviseSystem::acfunc[5] = { purelin, unitan, bitan, unisig, bisig } ;
ACFunc SuperviseSystem::difacfunc[5] = { dpurelin, dunitan, dbitan, dunisig, dbisig } ;
ACFunc SuperviseSystem::dif2acfunc[5] = { d2purelin, d2unitan, d2bitan, d2unisig, d2bisig } ;

SuperviseSystem::SuperviseSystem()
{
	Weight = 0 ;
	X = 0 ;
	activation = 0;
	Input = 0 ;
	neuron = 0;
	Desire = 0;
	Error = 0;
	index = 0 ;
	DataPresent = 0;

	// tree
	_proot = new HammingTreeNode ;
	_proot->parent = NULL ;
	_proot->pout = NULL ;
}

SuperviseSystem::~SuperviseSystem()
{
	DestroyBP() ;

	// tree
	DestroyTree(_proot) ;
	delete _proot ;
}

int SuperviseSystem::PreInit(){

	if( ! DataPresent )
		return 0 ;

	ReDistribute(1) ;
	return 1;

}

int SuperviseSystem::Load(const char* filename){

	const int bufsize = 1024 ;
	char str[bufsize] ;
	char blank[] = " \t" ;
	char * c; 
	int i, j, k, sign;

	FILE * fp = fopen(filename, "r");
	if( !fp ) 
		return 0 ;

	DestroyTree(_proot);

	DestroyBP() ;

	fgets(str, bufsize, fp); 
	sscanf(str, "%d", &num_layer) ;

	neuron = new int [num_layer+1] ;
	activation = new AC[num_layer+1] ;

	fgets(str, bufsize, fp);
	c = strtok(str, blank) ;

	// parse number of neurons
	for( i = 0 ; i <= num_layer ; i++ ){
		neuron[i] = atoi(c) ;
		c = strtok(NULL, blank);
	}

	fgets(str, bufsize, fp);
	c = strtok(str, blank);
	
	// parse activation function
	activation[0] = PURELIN ;
	for( i = 1 ; i <= num_layer ; i++ ){		
		if( strcmp( c, "BITAN") == 0 )
			activation[i] = BITAN ;
		else if( strcmp( c, "UNITAN") == 0) 
			activation[i] = UNITAN ;
		else if( strcmp( c, "UNISIG") == 0) 
			activation[i] = UNISIG ;
		else if( strcmp( c, "BISIG") == 0) 
			activation[i] = BISIG ;
		else if( strcmp( c, "PURELIN") == 0)
			activation[i] = PURELIN ;
		else 
			activation[i] = BITAN ;
		c = strtok(NULL, blank) ;
	}
	
	fgets(str, bufsize, fp);
	sscanf(str, "%d", &num_pat) ;


	Input = new double * [num_pat] ;
	Desire = new double * [num_pat] ;

	for( i = 0 ; i < num_pat ; i++) {
		Input[i] = new double [neuron[0]] ;
		Desire[i] = new double [neuron[num_layer]] ;
	}


	// parse input and desire output pattern
	for( i = 0 ; i < num_pat ; i++ ){
		fgets(str, bufsize, fp);
		c = strtok(str, blank);

		for( j = 0 ; j < neuron[0] ; j++ ){
			Input[i][j] = atof(c) ;
			c = strtok(NULL, blank);
		}

		for( j = 0 ; j < neuron[num_layer] ; j++ ){
			Desire[i][j] = atof(c) ;
			c = strtok(NULL, blank);
		}
	}

	fgets(str, bufsize, fp);
	sscanf(str, "%lf %lf %lf", &learn_rate, &alpha, &beta); 

	// memory allocation for weight
	
	Weight = new double ** [num_layer] ;		// weight

	for( i = 0 ; i < num_layer ; i++ ){
		Weight[i] = new double * [neuron[i+1]] ;
		for( j = 0 ; j < neuron[i+1] ; j++ ){
			Weight[i][j] = new double [neuron[i]+1] ;		// include bias weight, be carefual
			for( k = 0 ; k < neuron[i] ; k++ ){
				sign = rand() % 2 ;
				if( sign == 0 )
					sign = -1;
				Weight[i][j][k] = sign * ((double) rand()) / (RAND_MAX) * 2;	// random initial value
			}
			Weight[i][j][k] = 0.0 ;
		}		
	}

	X = new double * [num_layer+1] ;		// input, hidden, output

	for( i = 0 ; i < num_layer+1 ; i++ ){
		X[i] = new double [neuron[i]+1]	;// include bias 
		for( j = 0 ; j < neuron[i] ; j++ )
			X[i][j] = rand_weight(1.0) ;

		X[i][neuron[i]] = 1.0 ;			 // bias are all "1" , only weight is adjustable
	}

	// sumation hidden neuron input
	S = new double*[num_layer+1] ;
	for( i = 1 ; i <= num_layer ; i++ )
		S[i] = new double[neuron[i]] ;

	Error = new double * [num_layer] ;		// Error back-propogation 
	for( i = 0 ; i < num_layer ; i++ )
		Error[i] = new double [neuron[i+1]]	;

	index = new int [num_pat] ;
	for( i = 0 ; i < num_pat ; i++ )
		index[i] = i;

	fclose(fp) ;


	// now the bp system is with data 
	DataPresent = 1;	

	return 1;
}

int SuperviseSystem::DestroyBP() {
	int i, j;

	if( DataPresent ){

		for( i = 0 ; i < num_layer ; i++ )
			for( j = 0 ; j < neuron[i+1] ; j++ )
				delete [] Weight[i][j] ;

		for( i = 0 ; i < num_layer ; i++ )
			delete [] Weight[i] ;

		delete [] Weight ;

		Weight = 0; 

		// sumation hidden neuron input

		for( i = 1 ; i <= num_layer ; i++ )
			delete [] S[i] ;
		delete [] S ;
		S = 0 ;

		for( i = 0 ; i < num_layer+1 ; i++ )
			delete [] X[i] ;

		delete [] X ;

		X = 0 ;

		for( i = 0 ; i < num_layer ; i++ )
			delete [] Error[i];

		delete [] Error ;

		Error = 0;

		for( i = 0 ; i < num_pat ; i++ ){
			delete [] Input[i] ;
			delete [] Desire[i] ;
		}

		delete [] Input ;
		delete [] Desire; 
		delete [] neuron ;
		delete [] activation ;
		delete [] index ;

		Input = 0;
		Desire = 0;
		neuron = 0;
		activation = 0;
		index = 0;

		DataPresent = 0 ;
		return 1;
	}
	return 0;
}

int SuperviseSystem::DestroyTree(HammingTreeNode * root){

	if( !root ) 
		return 0;

	std::vector<HammingTreeNode *>::iterator iter ;

	if( root->pout )
		delete [] root->pout ;

	root->pout = 0 ;

	for( iter = root->_list_child.begin() ; iter != root->_list_child.end() ; iter++ ){
		
		DestroyTree(*iter) ;
		delete *iter ;

		*iter = 0 ;
	}

	root->parent = NULL ;
	root->_list_pattern.clear() ;
	root->_list_child.clear();

	return 1;
}

int SuperviseSystem::GetPattern(int layer){
	
	int i, num, pat ;
	num = neuron[layer] ;
	pat = 0x0000 ;

	if( activation[layer] == UNITAN )
		for( i = 0 ; i < num ; i++ ){
			if( X[layer][i] > alpha*beta / 2.0 )
				pat |= 0x1;

			pat <<= 1 ;
		}

	else if( activation[layer] == BITAN || activation[layer] == PURELIN)
		for( i = 0 ; i < num ; i++ ){
			if( X[layer][i] > 0 )
				pat |= 0x1;

			pat <<= 1 ;
		}
	
	return pat >> 1;
}

int SuperviseSystem::GetDesirePattern(int ipat){

	int i, num, pat ;
	num = neuron[num_layer] ;		// output dimension
	pat = 0x0000 ;

	if( activation[num_layer] == UNITAN )
		for( i = 0 ; i < num ; i++ ){
			if( Desire[ipat][i] > alpha*beta / 2.0 )
				pat |= 0x1;

			pat <<= 1 ;
		}

	else if( activation[num_layer] == BITAN || activation[num_layer] == PURELIN)
		for( i = 0 ; i < num ; i++ ){
			if( Desire[ipat][i] > 0 )
				pat |= 0x1;

			pat <<= 1 ;
		}

	return pat >> 1 ;
}

// from hidden to output
int SuperviseSystem::Sim1(double * in, double * output, int layer ){

	int i, j, k;
	double sum ;

	for( i = 0 ; i < neuron[layer] ; i++ )
		X[layer][i] = in[i] ;

	for( i = layer+1 ; i < num_layer + 1 ; i++ ){
		for( j = 0 ; j < neuron[i] ; j++ ){
			sum = 0.0 ;
			for( k = 0 ; k < neuron[i-1]+1 ; k++ )
				sum += Weight[i-1][j][k] * X[i-1][k] ;

			Eval_AC(X[i][j], sum, activation[i]) ;
		}
	}


	for ( i = 0 ; i < neuron[num_layer] ; i++ )
		output[i] = X[num_layer][i] ;

	return 1;
}

// form input to hidden
double * SuperviseSystem::Sim2(double * in, int layer) {

	int i, j, k;

	for( i = 0 ; i < neuron[0] ; i++ )
		X[0][i] = in[i] ;

	for( i = 1 ; i <= layer ; i++ ){
		for( j = 0 ; j < neuron[i] ; j++ ){
			S[i][j] = 0.0 ;
			for( k = 0 ; k < neuron[i-1]+1 ; k++ )
				S[i][j] += Weight[i-1][j][k] * X[i-1][k] ;

			Eval_AC(X[i][j], S[i][j], activation[i]) ;
		}
	}

	return X[layer] ;

}
double * SuperviseSystem::Sim2(int layer, int iPat) {

	int i, j, k;

	for( i = 0 ; i < neuron[0] ; i++ )
		X[0][i] = Input[iPat][i] ;

	for( i = 1 ; i <= layer ; i++ ){
		for( j = 0 ; j < neuron[i] ; j++ ){
			S[i][j] = 0.0 ;
			for( k = 0 ; k < neuron[i-1]+1 ; k++ )
				S[i][j] += Weight[i-1][j][k] * X[i-1][k] ;

			Eval_AC(X[i][j], S[i][j], activation[i]) ;
		}
	}

	return X[layer];
}

int SuperviseSystem::ReDistribute(double scale)
{
	if( !DataPresent )
		return 0 ;

	int i, j, k;
	int sign ;
	for( i = 0 ; i < num_layer ; i++ )
		for( j = 0 ; j < neuron[i+1] ; j++ )
			for( k = 0 ; k < neuron[i] + 1; k++ ){
				sign = rand() % 2 ;
				if( sign == 0 ) 
					sign = -1;
				Weight[i][j][k] = sign * ( (double) rand() / RAND_MAX ) * scale;
			}


	return 1;
}

HammingTreeNode * SuperviseSystem::BuildTree(){


	int i, j, k, m, bitpat, desire;

	HammingTreeNode *node, *ptr ;

	std::deque<HammingTreeNode *> q ;
	std::deque<HammingTreeNode *>::iterator iter, cmp_iter ;


	// construct hamming tree layer one, dump all Input into first layer
	for( i = 0 ; i < num_pat ; i++ ){	// for all patterns

		// copy input to network
		for( j = 0 ; j < neuron[0] ; j++ )
			X[0][j] = Input[i][j] ;			// include bias, br careful

		for( k = 0 ; k < neuron[1] ; k++ ){
			X[1][k] = 0.0 ;

			for( m = 0 ; m < neuron[0] + 1 ; m++ )		// include bias
				X[1][k] += Weight[0][k][m] * X[0][m] ; 

			Eval_AC(X[1][k], X[1][k], activation[1]) ;
		}
		
		bitpat = GetPattern(1) ;				// retrive the corner of hypercube 
		desire = GetDesirePattern(i);			// desired output for input[i] 

		for( iter = q.begin() ; iter != q.end() ; iter++ )
			if( (*iter)->bitpat == bitpat ) {
				
//				(*iter)->sum_leaf++ ;
				(*iter)->_list_pattern.push_back(i) ;		// add new pattern to this class

				if( (*iter)->desire != desire ) 
					(*iter)->state = Conflict ;				// conflict node if desire not the same

				break;
			}

		// if this kind of I/O relation is absent in layer 1
		if( iter == q.end() ){
			node = new HammingTreeNode ;

			// although we have binary pattern , still store the real value
			node->pout = new double [neuron[1]] ;
			for( j = 0 ; j < neuron[1] ; j++ )
				node->pout[j] = X[1][j] ;

			node->bitpat = bitpat;
			node->desire = desire;
			node->layer = 1 ;			// layer of this node
			node->sum_leaf = 1;			// i am a leaf node
			node->parent = NULL ;
			node->state = Pure ;
			//node->_list_child.clear() ;
			//node->_list_pattern.clear();
			node->_list_pattern.push_back(i) ;
			q.push_back(node) ;


		}
	}

	cmp_iter = q.end() ;

	DestroyTree(_proot) ;


	_proot->layer = num_layer + 1 ;
	_proot->sum_leaf = 0 ;
	_proot->state = Pure ;
	_proot->bitpat = 0 ;
	_proot->desire = 0 ;

	while( !q.empty() ){

		if( cmp_iter == q.begin() )
			cmp_iter = q.end() ;		// spare the search time if Dimension is very large

		ptr = q.front();

		// should not simulate output neuron, be careful
		if( ptr->layer == num_layer ) {
			if( ptr->state == Conflict )
				_proot->state = Conflict ;

			_proot->_list_child.push_back(ptr) ;
			_proot->sum_leaf += ptr->sum_leaf ;
			ptr->parent = _proot ;
			q.pop_front() ;
			continue ;
		}

		m = ptr->layer + 1;


		// restore pattern from node into X[m-1][]
		for( i = 0 ; i < neuron[m-1] ; i++ )
			X[m-1][i] = ptr->pout[i] ;


		// simulate layer m with input of this node
		for ( i = 0 ; i < neuron[m] ; i++ ){
			X[m][i] = 0.0 ;
			for( j = 0 ; j < neuron[m-1] + 1 ; j++ )
				X[m][i] += Weight[m-1][i][j] * X[m-1][j] ;

			Eval_AC(X[m][i], X[m][i], activation[m]) ;
		}

		bitpat = GetPattern(m) ;

		// for all created neuron in layer m in queue
		for( iter = cmp_iter ; iter != q.end() ; iter++ )
			if( (*iter)->bitpat == bitpat ){

				if( (*iter)->state == Conflict || 	// this parent is already in conflict state
					(*iter)->desire == ptr->desire ){ // this parent has same desire with child

					(*iter)->_list_child.push_back( ptr ) ;	// add child to list
					ptr->parent = *iter ;					// set parent
					(*iter)->sum_leaf += ptr->sum_leaf ;	// sumation leaf
					break ;
				}

				else if( (*iter)->desire != ptr->desire ){ // this parent has different desire with child
					(*iter)->state = Conflict ;
					(*iter)->_list_child.push_back( ptr ) ;
					ptr->parent = *iter ;
					(*iter)->sum_leaf += ptr->sum_leaf ;
					break ;
				}
			}

		// this output pattern absent in layer m, create a new node and push_back to queue
		if( iter == q.end() ){
			node = new HammingTreeNode ;

			// although we have binary pattern , still store the real value
			node->pout = new double [neuron[m]] ;
			for( j = 0 ; j < neuron[m] ; j++ )
				node->pout[j] = X[m][j] ;

			node->bitpat = bitpat ;
			node->desire = ptr->desire ;
			node->layer = m ;
			node->parent = NULL ;
			node->state = ptr->state ;
			node->_list_child.push_back(ptr) ;
			node->sum_leaf = ptr->sum_leaf ;
			ptr->parent = node ;
			q.push_back(node) ;

			node = 0 ;
		}
		
		q.pop_front() ;
	}

	return _proot ;
}

///////////////////////////////////////////////////////////
////////// function about draw tree
///////////////////////////////////////////////////////////
/*
#include <GL/glut.h>

void ShowStr(char * s, int count = 0 ){

	if( count == 0 ){
		char * c = s;
		while( *c != '\0' ){
			glutBitmapCharacter(GLUT_BITMAP_9_BY_15, *c) ;
			c++ ;
		}
	}

	else{
		int i;
		for( i = 0 ; i < count ; i++){
			if( s[i] == '\0' )
				return ;
			else
				glutBitmapCharacter(GLUT_BITMAP_9_BY_15, s[i]) ;
		}
	}
}

int SuperviseSystem::DrawTree(double left, double right, double bot, double top){

		double initX, initY, X, y, nx;
		double w_ival ;
		double h_ival ;

		double width = right - left ;
		double height = top - bot ;

		char str[128] ;
	
		std::deque<HammingTreeNode *> q ;
		std::deque<HammingTreeNode *>::iterator cmp_iter ;
		std::vector<HammingTreeNode *>::iterator iter ;
		HammingTreeNode * node ;

		if( !_proot )
			return 0;

		node = _proot ;

		nx = X = initX = left + 0.1 * width ;
		y = initY = top - 0.1 * height ;
		w_ival = width * 0.9 / node->sum_leaf ;
		h_ival = height * 0.9 / node->layer ;

		q.push_back(node) ;

		cmp_iter = q.end() ;

		while( !q.empty() ){

			node = q.front() ;

			if( cmp_iter == q.begin() ){
				cmp_iter = q.end() ;
				nx = X = initX ;
				y -= h_ival ;
			}

			if( node != _proot ){
				if( node->state == Pure ){
					glColor3f(1.0f, 1.0f, 1.0f) ;
					sprintf(str, "Pat: %X Des: %X", node->bitpat, node->desire);
					glRasterPos2d(X, y) ;
					ShowStr(str) ;
				}

				else if( node->state == Conflict ){
					glColor3f(1.0f, 0.0f, 0.0f) ;
					sprintf(str, "Pat: %X", node->bitpat);
					glRasterPos2d(X, y) ;
					ShowStr(str) ;
				}
			}

			glBegin(GL_POINTS);
			glVertex2d(X, y);
			glEnd();


			
			for( iter = node->_list_child.begin() ; iter != node->_list_child.end() ; iter++ ){		
			
				glBegin(GL_LINES);
				glVertex2d(X, y) ;
				glVertex2d(nx, y-h_ival) ;
				glEnd() ;

				nx += w_ival * (*iter)->sum_leaf;		// proceed position in child layer
				q.push_back(*iter) ;
			}
		
			X += w_ival * node->sum_leaf;		// increment the current layer position, because this parent is already done

			q.pop_front() ;		// next parent 

		}

		return 1;
}
*/