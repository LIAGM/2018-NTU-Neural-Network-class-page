#ifndef __BP_SYSTEM__
#define __BP_SYSTEM__

#include "SuperviseSystem.h"

class BPSystem : public SuperviseSystem{

public :

	BPSystem() ;
	virtual double Train() ;

protected :

}; 

#endif