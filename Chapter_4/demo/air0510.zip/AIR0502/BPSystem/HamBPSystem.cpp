#include <vector>
#include <queue>	

#include "HamBPSystem.h"

HamBPSystem::HamBPSystem(){
	_proot = new HammingTreeNode ;
	_proot->parent = NULL ;
	_proot->pout = NULL ;
}

HamBPSystem::~HamBPSystem(){

	DestroyTree(_proot) ;
	delete _proot ;

}

int HamBPSystem::Load(const char* filename){

	DestroyTree(_proot); 
	return BPSystem::Load(filename) ;
}


HammingTreeNode * HamBPSystem::BuildTree(){


	int i, j, k, m, bitpat, desire;

	HammingTreeNode *node, *ptr ;

	std::deque<HammingTreeNode *> q ;
	std::deque<HammingTreeNode *>::iterator iter, cmp_iter ;


	// construct hamming tree layer one, dump all Input into first layer
	for( i = 0 ; i < num_pat ; i++ ){	// for all patterns

		// copy input to network
		for( j = 0 ; j < neuron[0] ; j++ )
			X[0][j] = Input[i][j] ;			// include bias, br careful

		for( k = 0 ; k < neuron[1] ; k++ ){
			X[1][k] = 0.0 ;

			for( m = 0 ; m < neuron[0] + 1 ; m++ )		// include bias
				X[1][k] += Weight[0][k][m] * X[0][m] ; 
			

//			X[1][k] = Eval_AC(X[1][k], activation[0]) ;
			Eval_AC(X[1][k], X[1][k], activation[1]) ;
		}
		
		bitpat = GetPattern(1) ;				// retrive the corner of hypercube 
		desire = GetDesirePattern(i);			// desired output for input[i] 

		for( iter = q.begin() ; iter != q.end() ; iter++ )
			if( (*iter)->bitpat == bitpat ) {
				
				(*iter)->_list_pattern.push_back(i) ;		// add new pattern to this class

				if( (*iter)->desire != desire ) 
					(*iter)->state = Conflict ;				// conflict node if desire not the same

				break;
			}

		// if this kind of I/O relation is absent in layer 1
		if( iter == q.end() ){
			node = new HammingTreeNode ;

			// although we have binary pattern , still store the real value
			node->pout = new double [neuron[1]] ;
			for( j = 0 ; j < neuron[1] ; j++ )
				node->pout[j] = X[1][j] ;

			node->bitpat = bitpat;
			node->desire = desire;
			node->layer = 1 ;			// layer of this node
			node->sum_leaf = 1;			// i am a leaf node
			node->parent = NULL ;
			node->state = Pure ;
			//node->_list_child.clear() ;
			//node->_list_pattern.clear();
			node->_list_pattern.push_back(i) ;
			q.push_back(node) ;


		}
	}

	cmp_iter = q.end() ;

	DestroyTree(_proot) ;


	_proot->layer = num_layer + 1 ;
	_proot->sum_leaf = 0 ;
	_proot->state = Pure ;
	_proot->bitpat = 0 ;
	_proot->desire = 0 ;

	while( !q.empty() ){

		if( cmp_iter == q.begin() )
			cmp_iter = q.end() ;		// spare the search time if Dimension is very large

		ptr = q.front();

		// should not simulate output neuron, be careful
		if( ptr->layer == num_layer ) {
			if( ptr->state == Conflict )
				_proot->state = Conflict ;

			_proot->_list_child.push_back(ptr) ;
			_proot->sum_leaf += ptr->sum_leaf ;
			ptr->parent = _proot ;
			q.pop_front() ;
			continue ;
		}

		m = ptr->layer + 1;


		// restore pattern from node into X[m-1][]
		for( i = 0 ; i < neuron[m-1] ; i++ )
			X[m-1][i] = ptr->pout[i] ;


		// simulate layer m with input of this node
		for ( i = 0 ; i < neuron[m] ; i++ ){
			X[m][i] = 0.0 ;
			for( j = 0 ; j < neuron[m-1] + 1 ; j++ )
				X[m][i] += Weight[m-1][i][j] * X[m-1][j] ;

//			X[m][i] = Eval_AC(X[m][i], activation[m-1]) ;
			Eval_AC(X[m][i], X[m][i], activation[m]) ;
		}

		bitpat = GetPattern(m) ;

		// for all created neuron in layer m in queue
		for( iter = cmp_iter ; iter != q.end() ; iter++ )
			if( (*iter)->bitpat == bitpat ){

				if( (*iter)->state == Conflict || 	// this parent is already in conflict state
					(*iter)->desire == ptr->desire ){ // this parent has same desire with child

					(*iter)->_list_child.push_back( ptr ) ;	// add child to list
					ptr->parent = *iter ;					// set parent
					(*iter)->sum_leaf += ptr->sum_leaf ;	// sumation leaf
				}

				else if( (*iter)->desire != ptr->desire ){ // this parent has different desire with child
					(*iter)->state = Conflict ;
					(*iter)->_list_child.push_back( ptr ) ;
					ptr->parent = *iter ;
					(*iter)->sum_leaf += ptr->sum_leaf ;
				}
				else	continue ;

				
				break;				
			}

		// this output pattern absent in layer m, create a new node and push_back to queue
		if( iter == q.end() ){
			node = new HammingTreeNode ;

			// although we have binary pattern , still store the real value
			node->pout = new double [neuron[m]] ;
			for( j = 0 ; j < neuron[m] ; j++ )
				node->pout[j] = X[m][j] ;

			node->bitpat = bitpat ;
			node->desire = ptr->desire ;
			node->layer = m ;
			node->parent = NULL ;
			node->state = ptr->state ;
			node->_list_child.push_back(ptr) ;
			node->sum_leaf = ptr->sum_leaf ;
			ptr->parent = node ;
			q.push_back(node) ;
		}
		
		q.pop_front() ;
	}

	return _proot ;
}

int HamBPSystem::DestroyTree(HammingTreeNode * root){

	if( !root ) 
		return 0;

	std::vector<HammingTreeNode *>::iterator iter ;

	if( root->pout )
		delete [] root->pout ;

	for( iter = root->_list_child.begin() ; iter != root->_list_child.end() ; iter++ ){
		
		DestroyTree(*iter) ;
		delete *iter ;
	}

	root->parent = NULL ;
	root->_list_pattern.clear() ;
	root->_list_child.clear();

	return 1;
}


///////////////////////////////////////////////////////////
////////// function about draw tree
///////////////////////////////////////////////////////////

#include <GL/glut.h>

void ShowStr(char * s, int count = 0 ){

	if( count == 0 ){
		char * c = s;
		while( *c != '\0' ){
			glutBitmapCharacter(GLUT_BITMAP_9_BY_15, *c) ;
			c++ ;
		}
	}

	else{
		int i;
		for( i = 0 ; i < count ; i++){
			if( s[i] == '\0' )
				return ;
			else
				glutBitmapCharacter(GLUT_BITMAP_9_BY_15, s[i]) ;
		}
	}
}

int HamBPSystem::DrawTree(double left, double right, double bot, double top){

		double initX, initY, X, y, nx;
		double w_ival ;
		double h_ival ;

		double width = right - left ;
		double height = top - bot ;

		char str[128] ;
	
		std::deque<HammingTreeNode *> q ;
		std::deque<HammingTreeNode *>::iterator cmp_iter ;
		std::vector<HammingTreeNode *>::iterator iter ;
		HammingTreeNode * node ;

		if( !_proot )
			return 0;

		node = _proot ;

		nx = X = initX = left + 0.1 * width ;
		y = initY = top - 0.1 * height ;
		w_ival = width * 0.9 / node->sum_leaf ;
		h_ival = height * 0.9 / node->layer ;

		q.push_back(node) ;

		cmp_iter = q.end() ;

		while( !q.empty() ){

			node = q.front() ;

			if( cmp_iter == q.begin() ){
				cmp_iter = q.end() ;
				nx = X = initX ;
				y -= h_ival ;
			}

			if( node != _proot ){
				if( node->state == Pure ){
					glColor3f(1.0f, 1.0f, 1.0f) ;
					sprintf(str, "Pat: %X Des: %X", node->bitpat, node->desire);
					glRasterPos2d(X, y) ;
					ShowStr(str) ;
				}

				else if( node->state == Conflict ){
					glColor3f(1.0f, 0.0f, 0.0f) ;
					sprintf(str, "Pat: %X", node->bitpat);
					glRasterPos2d(X, y) ;
					ShowStr(str) ;
				}
			}

			glBegin(GL_POINTS);
			glVertex2d(X, y);
			glEnd();


			
			for( iter = node->_list_child.begin() ; iter != node->_list_child.end() ; iter++ ){		
			
				glBegin(GL_LINES);
				glVertex2d(X, y) ;
				glVertex2d(nx, y-h_ival) ;
				glEnd() ;

				nx += w_ival * (*iter)->sum_leaf;		// proceed position in child layer
				q.push_back(*iter) ;
			}
		
			X += w_ival * node->sum_leaf;		// increment the current layer position, because this parent is already done

			q.pop_front() ;		// next parent 

		}

		return 1;
}