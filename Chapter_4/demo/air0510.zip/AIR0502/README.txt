Instructions:
1. Run AIRDemo\Debug\AirDemo.exe
2. File -> Open, choose Data\p62.txt and OK
3. Once the data is loaded, DisplayMode, Training and AIR_Function menu are now accessible.
   You can control and view the training process now.

If you don't have Visual C++ 6 in your system, the demo may ask for some dll files. You can
either install VC++ 6 or copy the dll files from other computers to your system32 directory 
under your windows install path. Make sure the dll file is version 6.0.8168.0 or it may not
work properly. 