
%%%%%%%%%%%%%%%%%%%%
%
% code for SIR
%
%%%%%%%%%%%%%%%%%%%%
clear; clc; tic;

rand('seed',fix(100*sum(clock)));

%% input dataset iris
load parkinsons.mat

for i=1:size(in,1)
    in(i,:) = 2*(in(i,:)-min(in(i,:)))/(max(in(i,:))-min(in(i,:)))-1;
end
out(find(out==0)) = -1;
cv_idx = crossvalind('Kfold', size(in,2), 5);

sir_tr_acc = [];
sir_test_acc = [];

for k = 1:5

    tr_in = in(:,find(cv_idx~=k)); 
    test_in = in(:,find(cv_idx==k));
    tr_out = out(:,find(cv_idx~=k)); 
    test_out = out(:,find(cv_idx==k)); 

    neuron_num = [size(tr_in,1) 20];

    learning_rate_rep = 0.1;
    learning_rate_att = 0.01;
    a = 1; b = 1;

    %% in-distance
    distance = dist(tr_in).^2;

    ctr_matrix = zeros(length(tr_out));
    for i=1:length(tr_out)
        ctr_matrix(i,:) = (tr_out(i) == tr_out);
    end
    ctr_matrix(find(ctr_matrix==0)) = -1;

    layer = 1;
    max_epochs = 2000;
    layer = 1;
    while(layer>=1)
        e1_curve = [];
        e2_curve = [];
        w = 2*rand(neuron_num(layer+1),neuron_num(layer)+1)-1;
        for epochs=1:max_epochs
            d_w = zeros(size(w));

            %% out-distance
            v_out = w*[tr_in; -ones(1,size(tr_in,2))];
            y_out = a*tanh(b*v_out);
            out_pairs_dist = dist(y_out).^2;


            [min_pair_1 min_pair_2] = find(out_pairs_dist==min(out_pairs_dist(find(ctr_matrix==-1))));
            min_pair_idx = randsample(size(min_pair_1,1),1);
            min_pair_1 = min_pair_1(min_pair_idx,1);
            min_pair_2 = min_pair_2(min_pair_idx,1);
            diff_y = y_out(:,min_pair_1) - y_out(:,min_pair_2);
            e = -diff_y/norm(diff_y);
            pre_e1 = -out_pairs_dist(min_pair_1,min_pair_2);
            delta_p1 = e.*(b/a).*(a-y_out(:,min_pair_1)).*(a+y_out(:,min_pair_1));
            delta_p2 = e.*(b/a).*(a-y_out(:,min_pair_2)).*(a+y_out(:,min_pair_2));
            d_w = d_w + learning_rate_rep*(delta_p1*[ tr_in(:,min_pair_1); -1 ]'-...
                delta_p2*[ tr_in(:,min_pair_2); -1 ]');
            min_pair_1_pre = y_out(:,min_pair_1);
            min_pair_2_pre = y_out(:,min_pair_2);


            [max_pair_1 max_pair_2] = find(out_pairs_dist==max(out_pairs_dist(find(ctr_matrix==1))));
            max_pair_idx = randsample(size(max_pair_1,1),1);
            max_pair_1 = max_pair_1(max_pair_idx,1);
            max_pair_2 = max_pair_2(max_pair_idx,1);
            diff_y = y_out(:,max_pair_1) - y_out(:,max_pair_2);
            e = diff_y/norm(diff_y);
            pre_e2 = out_pairs_dist(max_pair_1,max_pair_2);
            delta_p1 = e.*(b/a).*(a-y_out(:,max_pair_1)).*(a+y_out(:,max_pair_1));
            delta_p2 = e.*(b/a).*(a-y_out(:,max_pair_2)).*(a+y_out(:,max_pair_2));
            d_w = d_w + learning_rate_att*(delta_p1*[ tr_in(:,max_pair_1); -1 ]'-...
                delta_p2*[ tr_in(:,max_pair_2); -1 ]');
            max_pair_1_pre = y_out(:,max_pair_1);
            max_pair_2_pre = y_out(:,max_pair_2);

            for i=(length(neuron_num)-1):-1:1
                w = w - d_w;
            end

            %% updated out-distance
            v_out = w*[tr_in; -ones(1,size(tr_in,2))];
            y_out = a*tanh(b*v_out);
            out_pairs_dist = dist(y_out).^2;

            e1 = -out_pairs_dist(min_pair_1,min_pair_2);
            e1_curve = [e1_curve e1];

            e2 = out_pairs_dist(max_pair_1,max_pair_2);
            e2_curve = [e2_curve e2];
        end
        W{layer} = w;

        tr_in = in(:,find(cv_idx~=k));
        for i=1:layer
            v_out = W{i}*[tr_in; -ones(1,size(tr_in,2))];
            y_out = a*tanh(b*v_out);
            tr_in = y_out;
        end

        if( pre_e2<0.1 )    % pre_e1<(-4*neuron_num(end)+2) &
            layer = -1;
        else
            layer = layer + 1;
            neuron_num = [neuron_num neuron_num(end)];
        end
    end
    layer = length(neuron_num)-1;

    tr_in = in(:,find(cv_idx~=k));
    for i=1:layer
        v_out = W{i}*[tr_in; -ones(1,size(tr_in,2))];
        y_out = a*tanh(b*v_out);
        tr_in = y_out;
    end

    %%%%%%%%%%%%%% labeling sector %%%%%%%%%%%%%%
    learning_rate = 0.1;
    bp_w{1} = (2*rand(5,neuron_num(end)+1)-1)/4;
    bp_w{2} = (2*rand(1,5+1)-1)/4;

    learning_curve_out = []; 
    for epochs=1:5000
        bp_y_out{1} = tr_in;
        for i=2:3
            bp_v_out{i} = bp_w{i-1}*[bp_y_out{i-1}; -ones(1,size(bp_y_out{i-1},2))];
            bp_y_out{i} = a*tanh(b*bp_v_out{i});
        end
        e = (bp_y_out{end}-tr_out);
        sum_mse = sum(e.^2);


        delta_p{3} = e*(b/a).*(a-bp_y_out{end}).*(a+bp_y_out{end});
        for i=(3-1):-1:2
            delta_p{i} = [((b/a)*(a-bp_y_out{i}).*(a+bp_y_out{i}))].*(delta_p{i+1}'*bp_w{i}(:,1:(end-1)))';
        end

        for i=(3-1):-1:1
            bp_d_w{i} = (delta_p{i+1}*[bp_y_out{i};-ones(1,size(bp_y_out{i},2))]')/size(tr_out,2);
        end

        for i=(3-1):-1:1
            bp_w{i} = bp_w{i} - learning_rate * bp_d_w{i};
        end

        learning_curve_out = [learning_curve_out sum_mse];
    end
    
    
    %% calculate training accuracy
    tr_in = in(:,find(cv_idx~=k));
    for i=1:layer
        v_out = W{i}*[tr_in; -ones(1,size(tr_in,2))];
        y_out = a*tanh(b*v_out);
        tr_in = y_out;
    end
    bp_y_out{1} = tr_in;
    for i=2:3
        bp_v_out{i} = bp_w{i-1}*[bp_y_out{i-1}; -ones(1,size(bp_y_out{i-1},2))];
        bp_y_out{i} = a*tanh(b*bp_v_out{i});
    end
    bp_tr_out = hardlims(bp_y_out{end});
    disp(sprintf('training accuracy: %.3f%%', 100*sum(tr_out == bp_tr_out)/length(bp_tr_out)));
    sir_tr_acc = [sir_tr_acc 100*sum(tr_out == bp_tr_out)/length(bp_tr_out)];
    
    
    %% calculate testing accuracy
    test_in = in(:,find(cv_idx==k));
    for i=1:layer
        v_out = W{i}*[test_in; -ones(1,size(test_in,2))];
        y_out = a*tanh(b*v_out);
        test_in = y_out;
    end
    bp_y_out{1} = test_in;
    for i=2:3
        bp_v_out{i} = bp_w{i-1}*[bp_y_out{i-1}; -ones(1,size(bp_y_out{i-1},2))];
        bp_y_out{i} = a*tanh(b*bp_v_out{i});
    end
    bp_test_out = hardlims(bp_y_out{end});
    disp(sprintf('testing accuracy: %.3f%%', 100*sum(test_out == bp_test_out)/length(bp_test_out)));
    sir_test_acc = [sir_test_acc 100*sum(test_out == bp_test_out)/length(bp_test_out)];
    
end

