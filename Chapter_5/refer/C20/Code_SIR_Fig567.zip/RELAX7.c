#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

int pattern[30][97];
double weight1[6][97];
double weight2[4][7];
double weight3[4][5];
double yy1[7];
double yy2[5];
double o[4];
double delta1[7];
double delta2[5];
double delta3[4];

char *output[10]={"n1","n2","n3","n4","n5","n6",
	"n7","n8","n9","n10"};
double rw1[6][97];
double rw2[4][7];
double rw3[4][5];
double ry1[7];
double ry2[5];
double ro[4];
double rs[4];

double desire[30][4]=
{
	{-1,-1,-1,-1}, {-1,-1,-1,-1}, {-1,-1,-1,-1},
	{-1,-1,-1,1}, {-1,-1,-1,1}, {-1,-1,-1,1},
	{-1,-1,1,-1}, {-1,-1,1,-1}, {-1,-1,1,-1},
	{-1,-1,1,1}, {-1,-1,1,1}, {-1,-1,1,1},
	{-1,1,-1,-1}, {-1,1,-1,-1}, {-1,1,-1,-1},
	{-1,1,-1,1}, {-1,1,-1,1}, {-1,1,-1,1},
	{-1,1,1,-1}, {-1,1,1,-1}, {-1,1,1,-1},
	{-1,1,1,1}, {-1,1,1,1}, {-1,1,1,1},
	{1,-1,-1,-1}, {1,-1,-1,-1}, {1,-1,-1,-1},
	{1,-1,-1,1}, {1,-1,-1,1}, {1,-1,-1,1},
};


readinput()
{
	FILE *in;
	int i,j;
	char d;
	in = fopen("input.pat", "rt");

	j = 0;
	while(!feof(in)) {
		i=0;
		while(i<96) {
			d=(char)fgetc(in);
			if (d != '\n') {
				if (d == '1')
				pattern[j][i]=1;
				else if (d== '0')
				pattern[j][i]=-1;

				i++;
			}
		}
		j++;
	}
	fclose(in);
	for(i=0;i<30;i++)
	pattern[i][97]=-1;
}
void initial()
{
	int i,j;



	for(i=0;i<4;i++) {
		for(j=0;j<4;j++) {
			weight2[i][j]=(double)(rand()%1024)/256.0-2.0;
			weight3[i][j]=(double)(rand()%1024)/256.0-2.0;
		}
		weight2[i][4]=(double)(rand()%1024)/256.0-2.0;
		weight2[i][5]=(double)(rand()%1024)/256.0-2.0;
		weight2[i][6]=(double)(rand()%1024)/256.0-2.0;
		weight3[i][4]=(double)(rand()%1024)/256.0-2.0;
	}	

	for(j=0;j<6;j++) {
		for(i=0;i<96;i++){
			weight1[j][i]=(double)(rand()%1024)/256.0-2.0;
		}
		weight1[j][96]=(double)(rand()%1024)/256.0-2.0;
	}

}

double f(double net){
	return(2/(1+exp(-1*net))-1);
}

void relax()
{
	int i,j,m,n,c,k;
	double tmp;
	int p;
	int bits[15];
	int min[14];
	int wm;
	double E,Emin;

	for(i=0;i<15;i++) bits[i] = 0;


	Emin=10000;

	for(c=0;c<15;c++) {
		/* assign */
		for(m=0;m<6;m++) for(n=0;n<97;n++) rw1[m][n] = weight1[m][n];
		for(m=0;m<4;m++) for(n=0;n<7;n++)  rw2[m][n] = weight2[m][n];
		for(m=0;m<4;m++) for(n=0;n<5;n++)  rw3[m][n] = weight3[m][n];
		for(m=0;m<7;m++)  ry1[m] = yy1[m];
		for(m=0;m<5;m++)  ry2[m] = yy2[m];
		for(m=0;m<4;m++)   ro[m] = o[m];


		i=0;
		while (i<15) bits[i++] = 0;
		bits[c] = 1;

		for(i=0;i<6;i++) {
			if (bits[i]==1) {
				for(m=0;m<97;m++)
				rw1[i][m] = -1*rw1[i][m];
			}
		}
		for(i=0;i<4;i++) {
			if (bits[i+6]==1) {
				for(m=0;m<7;m++)
				rw2[i][m] = -1*rw2[i][m];
			}
		}
		for(i=0;i<4;i++) {
			if (bits[i+10]==1) {
				for(m=0;m<5;m++)
				rw3[i][m] = -1*rw3[i][m];
			}
		}


		E=0;

		for(p=0;p<30;p++) {
			/* first layer */
			for(j=0;j<6;j++) {
				tmp=0;
				for(m=0;m<97;m++)
				tmp+=pattern[p][m]*rw1[j][m];
				ry1[j]=f(tmp);
				/*ry1[j] = (tmp > 0) ? 1 : -1;*/
			}
			ry1[6] = -1;

			/* second layer */
			for(j=0;j<4;j++) {
				tmp = 0;
				for(m=0;m<7;m++)
				tmp+=ry1[m]*rw2[j][m];
				ry2[j]=f(tmp);
				/*ry2[j]=(tmp >0) ?1 :-1;*/
			}
			ry2[4] = -1;

			/* third layer */
			for(k=0;k<4;k++) {
				tmp=0;
				for(m=0;m<5;m++)
				tmp+=ry2[m]*rw3[k][m];
				ro[k]=f(tmp);
				rs[k]=(tmp > 0) ? 1 : -1;
			}

			for(k=0;k<4;k++) {
				E+=0.5*(desire[p][k]-rs[k])*(desire[p][k]-rs[k]);
			}

		}/*p*/
		printf("%f ",E);

		if (E < Emin) {
			Emin = E;
			for(k=0;k<14;k++)
			min[k]=bits[k];
			wm=c;
		}


	}/*c*/

	for(i=0;i<6;i++) {
		if (min[i]) {
			for(m=0;m<97;m++)
			weight1[i][m] = -1*weight1[i][m];
		}
	}
	for(i=0;i<4;i++) {
		if (min[i+6]) {
			for(m=0;m<7;m++)
			weight2[i][m] = -1*weight2[i][m];
		}
	}
	for(i=0;i<4;i++) {
		if (min[i+10]) {
			for(m=0;m<5;m++)
			weight3[i][m] = -1*weight3[i][m];
		}
	}
	printf("\n");
	printf("%d ",wm);printf("\n");
}

void noise()
{
	int i,j;
	int n;
	for(i=0;i<30;i+=3)
	for(j=0;j<96;j++)
	pattern[i+1][j]=pattern[i][j];

	for(i=0;i<30;i+=3) {
		for(j=0;j<10;j++) {
			n = rand() %96;
			pattern[i+1][n] = -pattern[i][n];
		}
	}
}

int main()
{
	int i,j,k,m,n;
	int p,iter;
	double tmp;
	double E;
	FILE *out;
	int count;
	/*time_t tloc;*/

	//randomize();
	srand(time(NULL));
	readinput();

	for(count=0;count<10;count++)
	{
		out=fopen(output[count],"w+");

		/*	srand((int)(time(&tloc)));*/
		initial();


		for(iter=0;iter<200;iter++) {

			/*noise();*/
			E=0;
			for(p=0;p<30;p++) {

				/* first layer */
				for(j=0;j<6;j++) {
					tmp=0;
					for(m=0;m<97;m++)
					tmp+=pattern[p][m]*weight1[j][m];
					yy1[j]=f(tmp);
				}
				yy1[6] = -1;

				/* second layer */
				for(j=0;j<4;j++) {
					tmp = 0;
					for(m=0;m<7;m++)
					tmp+=yy1[m]*weight2[j][m];
					yy2[j]=f(tmp);
				}
				yy2[4] = -1;

				/* third layer */
				for(k=0;k<4;k++) {
					tmp=0;
					for(m=0;m<5;m++)
					tmp+=yy2[m]*weight3[k][m];
					o[k]=f(tmp);
				}

				for(k=0;k<4;k++) {
					E+=0.5*(desire[p][k]-o[k])*(desire[p][k]-o[k]);
				}

				/* third layer */
				for(k=0;k<4;k++) {
					delta3[k]=0.5*(desire[p][k]-o[k])*(1-o[k]*o[k]);
				}

				/* second layer */
				for(j=0;j<5;j++) {
					tmp = 0;
					for(k=0;k<4;k++) {
						tmp+=delta3[k]*weight3[k][j];
					}
					delta2[j]=0.5*(1-yy2[j]*yy2[j])*tmp;
				}

				/* first layer */
				for(j=0;j<7;j++) {
					tmp = 0;
					for(k=0;k<5;k++) {
						tmp+=delta2[k]*weight2[k][j];
					}
					delta1[j]=0.5*(1-yy1[j]*yy1[j])*tmp;
				}

				for(k=0;k<4;k++){
					for(j=0;j<5;j++)
					weight3[k][j]=weight3[k][j]+0.03*delta3[k]*yy2[j];
				}
				for(k=0;k<4;k++){
					for(j=0;j<7;j++)
					weight2[k][j]=weight2[k][j]+0.03*delta2[k]*yy1[j];
				}
				for(j=0;j<6;j++){
					for(i=0;i<97;i++)
					weight1[j][i]=weight1[j][i]+0.03*delta1[j]*pattern[p][i];
				}
			} /*p<30*/

			E=E/30; /*10 patterns*/
			fprintf(out,"%f\n",E);
			if(!(iter%10)) relax();

		} /*iter*/

		/*
		for(p=0;p<30;p=p+3) {

		for(j=0;j<6;j++) {
		tmp=0;
		for(m=0;m<97;m++)
			tmp+=pattern[p][m]*weight1[j][m];
		yy1[j]=f(tmp);
		}
		yy1[6] = -1;

		for(j=0;j<4;j++) {
		tmp = 0;
		for(m=0;m<7;m++)
			tmp+=yy1[m]*weight2[j][m];
		yy2[j]=f(tmp);
		}
		yy2[4] = -1;

		for(k=0;k<4;k++) {
		tmp=0;
		for(m=0;m<5;m++)
			tmp+=yy2[m]*weight3[k][m];
		o[k]=f(tmp);
		}

		for(k=0;k<4;k++) {
		i = (o[k] >0) ? 1 : 0;
		fprintf(out,"%d",i);
		}
		fprintf(out,"\n");
		}
	*/
		fclose(out);
	} /*count*/
	return 0;
}
